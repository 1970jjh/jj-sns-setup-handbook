"""스레드(Threads) API 인증 — 최초 1회 실행.

    python src/threads_auth.py

Meta 개발자 앱의 App ID / App Secret 을 config.json 의 threads 항목에 넣어두면,
브라우저를 띄워 사용자가 승인하고 장기 토큰(60일)을 .auth/threads.json 에 저장한다.
이후 발행 스크립트가 이 토큰을 쓰고, 만료가 가까우면 자동 갱신한다.

Meta는 OAuth 리다이렉트를 HTTPS로만 허용하므로 로컬에 자체 서명 인증서를 만들어
https://localhost:8443/callback 으로 받는다. 이 주소를 앱 대시보드의
'Valid OAuth Redirect URIs' 에 **똑같이** 등록해야 한다.
"""

from __future__ import annotations

import http.server
import json
import ssl
import subprocess
import sys
import threading
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.session import load_config  # noqa: E402

AUTH_DIR = PROJECT_ROOT / ".auth"
TOKEN_PATH = AUTH_DIR / "threads.json"
CERT_PATH = AUTH_DIR / "localhost-cert.pem"
KEY_PATH = AUTH_DIR / "localhost-key.pem"

REDIRECT_HOST = "localhost"
REDIRECT_PORT = 8443
REDIRECT_URI = f"https://{REDIRECT_HOST}:{REDIRECT_PORT}/callback"

AUTHORIZE_URL = "https://threads.net/oauth/authorize"
TOKEN_URL = "https://graph.threads.net/oauth/access_token"
EXCHANGE_URL = "https://graph.threads.net/access_token"
REFRESH_URL = "https://graph.threads.net/refresh_access_token"

SCOPES = "threads_basic,threads_content_publish"
KST = timezone(timedelta(hours=9))

_received: dict[str, str] = {}


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """OAuth 리다이렉트를 한 번 받아 인증 코드를 꺼낸다."""

    def do_GET(self):  # noqa: N802 - http.server 규약
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        _received.update({key: value[0] for key, value in params.items()})

        ok = "code" in _received
        body = (
            "<h2>인증이 완료되었습니다. 이 창을 닫아주세요.</h2>"
            if ok
            else f"<h2>인증 실패</h2><p>{_received.get('error_description', '')}</p>"
        )
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def log_message(self, *args):  # 콘솔을 조용하게
        return


def ensure_cert() -> None:
    """자체 서명 인증서가 없으면 만든다 (Meta가 HTTPS만 허용하기 때문)."""
    if CERT_PATH.is_file() and KEY_PATH.is_file():
        return
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    print("자체 서명 인증서를 생성합니다...")
    subprocess.run(
        [
            "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
            "-keyout", str(KEY_PATH), "-out", str(CERT_PATH),
            "-days", "3650", "-subj", "/CN=localhost",
        ],
        check=True, capture_output=True,
    )


def post_form(url: str, data: dict) -> dict:
    body = urllib.parse.urlencode(data).encode()
    request = urllib.request.Request(url, data=body, method="POST")
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode())


def get_json(url: str, params: dict) -> dict:
    full = f"{url}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(full, timeout=30) as response:
        return json.loads(response.read().decode())


def save_token(payload: dict, user_id: str) -> None:
    expires_in = int(payload.get("expires_in", 0))
    record = {
        "access_token": payload["access_token"],
        "user_id": user_id,
        "expires_at": (datetime.now(KST) + timedelta(seconds=expires_in)).isoformat(
            timespec="seconds"
        ),
    }
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_PATH.write_text(json.dumps(record, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"[저장] {TOKEN_PATH}")
    print(f"  만료: {record['expires_at']}")


def load_token() -> dict | None:
    if not TOKEN_PATH.is_file():
        return None
    try:
        return json.loads(TOKEN_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def refresh_if_needed(margin_days: int = 7) -> dict | None:
    """만료가 가까우면 장기 토큰을 갱신한다. 발행 직전에 호출한다."""
    token = load_token()
    if token is None:
        return None
    try:
        expires_at = datetime.fromisoformat(token["expires_at"])
    except (KeyError, ValueError):
        return token

    if expires_at - datetime.now(KST) > timedelta(days=margin_days):
        return token

    print("  스레드 토큰 만료가 가까워 갱신합니다...")
    try:
        payload = get_json(
            REFRESH_URL,
            {"grant_type": "th_refresh_token", "access_token": token["access_token"]},
        )
        save_token(payload, token["user_id"])
        return load_token()
    except Exception as error:
        print(f"  [경고] 토큰 갱신 실패: {error}")
        return token


def main() -> int:
    config = load_config().get("threads", {})
    app_id = config.get("app_id", "").strip()
    app_secret = config.get("app_secret", "").strip()

    if not app_id or not app_secret:
        print("[실패] config.json 에 threads.app_id / threads.app_secret 이 없습니다.")
        print("  Meta 개발자 앱을 만든 뒤 아래 형태로 넣어주세요:")
        print('  "threads": { "app_id": "...", "app_secret": "..." }')
        return 1

    ensure_cert()

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=str(CERT_PATH), keyfile=str(KEY_PATH))
    server = http.server.HTTPServer((REDIRECT_HOST, REDIRECT_PORT), _CallbackHandler)
    server.socket = context.wrap_socket(server.socket, server_side=True)

    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()

    auth_url = f"{AUTHORIZE_URL}?" + urllib.parse.urlencode(
        {
            "client_id": app_id,
            "redirect_uri": REDIRECT_URI,
            "scope": SCOPES,
            "response_type": "code",
        }
    )
    print("=" * 66)
    print("브라우저에서 스레드 계정(@YOUR_INSTAGRAM_ID)으로 로그인하고 권한을 승인해주세요.")
    print("=" * 66)
    print(f"\n{auth_url}\n")
    print("※ '연결이 비공개가 아닙니다' 경고가 뜨면 [고급] → [계속]을 눌러주세요.")
    print("   자체 서명 인증서라 뜨는 정상적인 경고입니다.\n")
    webbrowser.open(auth_url)

    thread.join(timeout=300)
    server.server_close()

    code = _received.get("code")
    if not code:
        print(f"[실패] 인증 코드를 받지 못했습니다. {_received.get('error_description', '')}")
        return 1

    print("인증 코드 수신 — 토큰으로 교환합니다...")
    try:
        short = post_form(
            TOKEN_URL,
            {
                "client_id": app_id,
                "client_secret": app_secret,
                "grant_type": "authorization_code",
                "redirect_uri": REDIRECT_URI,
                "code": code,
            },
        )
        user_id = str(short["user_id"])

        long_lived = get_json(
            EXCHANGE_URL,
            {
                "grant_type": "th_exchange_token",
                "client_secret": app_secret,
                "access_token": short["access_token"],
            },
        )
    except Exception as error:
        print(f"[실패] 토큰 발급 실패: {error}")
        return 1

    save_token(long_lived, user_id)
    print("\n[완료] 스레드 인증이 끝났습니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
