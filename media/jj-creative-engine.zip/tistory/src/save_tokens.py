# -*- coding: utf-8 -*-
"""메모장에 붙여넣은 토큰들을 읽어 알아서 제자리에 저장한다.

    python src/save_tokens.py "C:/sns-auto/토큰.txt"

참가자는 «어느 줄이 무슨 토큰인지» 적을 필요가 없다. 받은 값을 한 줄에 하나씩
붙여넣기만 하면, 이 스크립트가 실제 서버에 물어봐서 스스로 종류를 가려낸다.

  · 스레드 토큰   → .auth/threads.json
  · 인스타 토큰   → .auth/instagram.json
  · 제미나이 키   → ../shorts-remotion/.env  의 GEMINI_API_KEY

토큰 값은 화면에 절대 출력하지 않는다. 확인된 계정 이름만 보여준다.
저장이 끝나면 원본 메모 파일을 지울지 물어본다(--delete 를 주면 묻지 않고 지운다).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SHORTS_ENV = PROJECT_ROOT.parent / "shorts-remotion" / ".env"
KST = timezone(timedelta(hours=9))
VALID_DAYS = 60
MIN_LEN = 50

CHANNELS = {
    "threads": {
        "path": PROJECT_ROOT / ".auth" / "threads.json",
        "verify": "https://graph.threads.net/v1.0/me",
        "label": "스레드",
    },
    "instagram": {
        "path": PROJECT_ROOT / ".auth" / "instagram.json",
        "verify": "https://graph.instagram.com/v21.0/me",
        "label": "인스타",
    },
}


def read_lines(path: Path) -> list[str]:
    """메모장 파일을 읽는다. 한글 윈도우 메모장은 cp949 로 저장되기도 한다."""
    for enc in ("utf-8-sig", "utf-8", "cp949"):
        try:
            return path.read_text(encoding=enc).splitlines()
        except UnicodeDecodeError:
            continue
    raise SystemExit(f"[중단] 파일을 읽지 못했습니다: {path}")


def candidates(lines: list[str]) -> list[str]:
    """줄에서 토큰처럼 생긴 값만 골라낸다. 'threads=' 같은 라벨은 떼어낸다."""
    out: list[str] = []
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line and len(line.split("=", 1)[0]) < 20:
            line = line.split("=", 1)[1].strip()
        line = line.strip("\"'` ")
        if len(line) >= MIN_LEN or line.startswith("AIza"):
            if line not in out:
                out.append(line)
    return out


def verify(token: str, channel: dict) -> dict | None:
    url = channel["verify"] + "?" + urllib.parse.urlencode(
        {"fields": "id,username", "access_token": token}
    )
    try:
        with urllib.request.urlopen(url, timeout=25) as res:
            return json.loads(res.read().decode())
    except Exception:
        return None


def save_channel(name: str, token: str, profile: dict) -> str:
    channel = CHANNELS[name]
    record = {
        "access_token": token,
        "user_id": str(profile["id"]),
        "expires_at": (datetime.now(KST) + timedelta(days=VALID_DAYS)).isoformat(
            timespec="seconds"
        ),
    }
    channel["path"].parent.mkdir(parents=True, exist_ok=True)
    channel["path"].write_text(
        json.dumps(record, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    return f"@{profile.get('username', '?')}"


def save_gemini(key: str) -> None:
    SHORTS_ENV.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    if SHORTS_ENV.exists():
        lines = [
            l for l in SHORTS_ENV.read_text(encoding="utf-8").splitlines()
            if not l.startswith("GEMINI_API_KEY=")
        ]
    lines.append(f"GEMINI_API_KEY={key}")
    # BOM 이 붙으면 엔진이 키를 못 읽는다 — ascii 로 쓴다
    SHORTS_ENV.write_text("\n".join(lines) + "\n", encoding="ascii")


def main() -> int:
    ap = argparse.ArgumentParser(description="메모 파일에서 토큰을 읽어 저장한다")
    ap.add_argument("memo", help="토큰을 붙여넣은 텍스트 파일 경로")
    ap.add_argument("--delete", action="store_true", help="저장 후 메모 파일을 묻지 않고 삭제")
    ap.add_argument("--keep", action="store_true", help="메모 파일을 남긴다")
    args = ap.parse_args()

    memo = Path(args.memo)
    if not memo.is_file():
        print(f"[중단] 파일이 없습니다: {memo}")
        return 1

    values = candidates(read_lines(memo))
    if not values:
        print("[중단] 토큰처럼 보이는 줄이 없습니다. 메모장에 값을 붙여넣었는지 확인해주세요.")
        return 1

    print(f"메모 파일에서 후보 {len(values)}개를 찾았습니다. 서버에 확인합니다...\n")
    done: dict[str, str] = {}
    unknown = 0

    for value in values:
        if value.startswith("AIza"):
            save_gemini(value)
            done["제미나이"] = "키 저장됨"
            continue
        matched = False
        for name, channel in CHANNELS.items():
            if name in done:
                continue
            profile = verify(value, channel)
            if profile and "id" in profile:
                done[channel["label"]] = save_channel(name, value, profile)
                matched = True
                break
        if not matched:
            unknown += 1

    print("=========== 저장 결과 ===========")
    for label in ("스레드", "인스타", "제미나이"):
        if label in done:
            print(f"  {label:6} 저장됨   {done[label]}")
        else:
            print(f"  {label:6} 없음")
    if unknown:
        print(f"\n  ⚠ 확인되지 않은 값 {unknown}개 — 만료됐거나 잘못 복사된 토큰일 수 있습니다.")

    if not args.keep:
        remove = args.delete
        if not remove:
            answer = input("\n메모 파일을 지울까요? (지우는 것을 권합니다) [Y/n] ").strip().lower()
            remove = answer in ("", "y", "yes")
        if remove:
            memo.unlink(missing_ok=True)
            print("메모 파일을 지웠습니다.")

    return 0 if done else 1


if __name__ == "__main__":
    raise SystemExit(main())
