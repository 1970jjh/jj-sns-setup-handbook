"""썸네일을 생성하고 **결과를 검증해** 원고에 배정한다.

    python src/make_thumbs.py <logNo>:<영문프롬프트> [<logNo>:<프롬프트> ...]

2026-07-30 사고 방지용. Google Flow 세션이 만료되면 flow_generate.py는
0장을 만들고도 정상 종료한다. 그대로 두면 이전 배치에 남은 파일을 집어 쓰게 되어
**다른 글의 썸네일이 붙은 채 발행되는 사고**가 난다. 실제로 발생했다.

따라서 이 스크립트는
  1) 실행 시작 시각을 기록하고
  2) 생성 후 report.json의 files 개수를 확인하고
  3) 그 시각 이후에 만들어진 파일만 후보로 삼는다
셋 중 하나라도 어긋나면 아무것도 배정하지 않고 실패로 끝낸다.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
# 🔴 병렬 생성 지원 (2026-08-05): Flow 계정을 IMAGE_FLOW_PROFILE 로 나눠 두 브라우저를
# 동시에 돌릴 때, 출력 폴더가 하나면 mtime 기반 새파일 판정이 서로의 결과물을 집어간다.
# 병렬 실행하는 쪽은 THUMBS_DIR 환경변수로 자기 전용 폴더를 지정해야 한다.
THUMBS_DIR = Path(os.environ.get("THUMBS_DIR", PROJECT_ROOT / "thumbs"))
FLOW_SCRIPT = Path.home() / ".claude/skills/image-flow/scripts/flow_generate.py"


def main() -> int:
    if len(sys.argv) < 2:
        print("사용법: python src/make_thumbs.py <logNo>:<프롬프트> ...")
        return 1

    jobs = []
    for raw in sys.argv[1:]:
        log_no, _, prompt = raw.partition(":")
        if not prompt.strip():
            print(f"[실패] 프롬프트가 비었습니다: {raw[:40]}")
            return 1
        jobs.append((log_no.strip(), prompt.strip()))

    THUMBS_DIR.mkdir(parents=True, exist_ok=True)
    started = time.time()

    print(f"썸네일 {len(jobs)}건 생성 시작...")
    result = subprocess.run(
        [
            sys.executable, str(FLOW_SCRIPT),
            "--prompts", "||".join(prompt for _, prompt in jobs),
            "--model", "nano-banana-2",
            "--ratio", "16:9",
            "--count", "4",          # --count 1은 '1x' 탭이 없어 실패한다 (실측)
            "--project", "JJ-Tistory",
            "--out", str(THUMBS_DIR),
        ]
        # 시연 촬영용: FLOW_HEADED=1 이면 Flow 창을 띄워 생성 과정을 화면 녹화할 수 있다
        + (["--headed"] if os.environ.get("FLOW_HEADED") == "1" else []),
        capture_output=True, text=True,
    )
    tail = (result.stdout or "").strip().splitlines()[-4:]
    for line in tail:
        print("  " + line)

    # --- 검증: 이번 실행 이후에 만들어진 파일만 쓴다 ------------------------
    # report.json의 files 필드는 채워지지 않을 때가 있어(실측) 신뢰하지 않는다.
    # 파일 mtime이 이번 실행 시작 시각보다 새로운지가 유일하게 확실한 신호다.
    fresh = sorted(
        (path for path in THUMBS_DIR.glob("*.jpg") if path.stat().st_mtime >= started),
        key=lambda path: path.name,
    )
    if not fresh:
        print("[실패] 이번 실행으로 새로 만들어진 파일이 없습니다.")
        print("  → Google Flow 세션이 만료됐을 가능성이 높습니다.")
        print("  → python ~/.claude/skills/image-flow/scripts/flow_login.py 실행 후 재시도하세요.")
        print("  → 이전 배치 파일을 대신 쓰지 않습니다 (다른 글 썸네일이 붙는 사고 방지).")
        return 1

    print(f"  새로 생성된 파일 {len(fresh)}개 확인")

    # 프롬프트 순서(01_, 02_ ...)와 원고 순서를 맞춘다.
    assigned = 0
    for index, (log_no, _) in enumerate(jobs, 1):
        prefix = f"{index:02d}_"
        candidates = [path for path in fresh if path.name.startswith(prefix)]
        if not candidates:
            print(f"[실패] {log_no}: {prefix}로 시작하는 새 파일이 없습니다.")
            return 1
        target = THUMBS_DIR / f"{log_no}.png"
        target.write_bytes(candidates[0].read_bytes())
        print(f"  {log_no} <- {candidates[0].name}")
        assigned += 1

    print(f"[완료] 썸네일 {assigned}건 배정")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
