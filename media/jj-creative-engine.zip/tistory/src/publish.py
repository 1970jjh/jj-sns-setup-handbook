"""티스토리 자동 발행.

    python src/publish.py posts/example.json            # 발행
    python src/publish.py posts/example.json --draft    # 발행 직전까지만 (레이어 열고 정지)
    python src/publish.py posts/example.json --headed   # 창 띄우고 확인

발행 절차 (실측 검증된 순서):
  1) 에디터를 연다. 임시저장 복구 confirm은 거절한다.
  2) 제목 입력 (#post-title-inp)
  3) 이미지를 먼저 전부 업로드하고, 티스토리가 만든 <figure> 마크업을 순서대로 수집
  4) 본문 HTML의 자리표시자를 3)의 마크업으로 치환해
     tinymce.activeEditor.setContent()로 주입
  5) 태그 입력 → '완료' → 공개설정 → '공개 발행'
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeout  # noqa: E402

from src import selectors  # noqa: E402
from src.render import (  # noqa: E402
    IMAGE_PLACEHOLDER,
    ManuscriptError,
    collect_images,
    load_manuscript,
    render_html,
)
from src.session import load_config, open_context  # noqa: E402
from src import sync_state  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"

# 티스토리가 띄운 알림창 메시지를 모아둔다 (실패 원인 진단용)
DIALOG_LOG: list[str] = []

EDITOR_BOOT_MS = 6000
UPLOAD_WAIT_MS = 9000


class PublishError(RuntimeError):
    """발행 도중 복구 불가능한 문제."""


class DailyLimitReached(PublishError):
    """티스토리 일일 공개 발행 한도(15건)에 걸렸다. 오늘은 더 올릴 수 없다."""


# 티스토리가 한도 초과 시 띄우는 문구의 특징적인 부분
_DAILY_LIMIT_MARK = "하루에 새롭게 공개 발행할 수 있는 글"


# ---------------------------------------------------------------- 공통 유틸


def _slug(text: str) -> str:
    return re.sub(r"[^0-9a-z가-힣]+", "-", text.lower()).strip("-") or "unknown"


def _capture(page: Page, stem: str, with_html: bool) -> Path | None:
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        page.screenshot(path=str(DEBUG_DIR / f"{stem}.png"), full_page=True)
        if with_html:
            (DEBUG_DIR / f"{stem}.html").write_text(page.content(), encoding="utf-8")
        return DEBUG_DIR / f"{stem}.png"
    except Exception:
        return None


def _dump_debug(page: Page, what: str) -> Path | None:
    """실패 지점의 화면과 DOM을 남긴다."""
    return _capture(page, f"fail-{_slug(what)}", with_html=True)


def _snapshot(page: Page, what: str) -> Path | None:
    """정상 흐름의 확인용 화면 (실패가 아니므로 fail- 접두사를 붙이지 않는다)."""
    return _capture(page, _slug(what), with_html=False)


def _fail(page: Page, what: str, detail: str) -> PublishError:
    capture = _dump_debug(page, what)
    hint = f"\n  → 화면 캡처: {capture}" if capture else ""
    return PublishError(
        f"{detail}\n"
        f"  → 에디터가 개편됐다면 python src/inspect_editor.py 로 DOM을 다시 뜨고\n"
        f"     src/selectors.py 를 갱신하세요.{hint}"
    )


def _dialog_hint() -> str:
    """티스토리가 띄운 알림창 메시지를 실패 메시지에 덧붙인다."""
    if not DIALOG_LOG:
        return ""
    return "\n  → 티스토리 알림: " + " / ".join(DIALOG_LOG[-3:])


def body_frame(page: Page):
    """본문 TinyMCE iframe의 body 로케이터."""
    return page.frame_locator(selectors.BODY_IFRAME).locator("body")


# ---------------------------------------------------------------- 발행 단계


def open_editor(page: Page, blog_url: str) -> None:
    def on_dialog(dialog):
        # 티스토리가 띄우는 알림을 조용히 삼키면 실패 원인을 영영 못 본다.
        # (2026-07-30: 발행 실패 원인이 여기에 가려져 있었다)
        DIALOG_LOG.append(dialog.message)
        print(f"  [알림창] {dialog.message[:120]}")
        dialog.dismiss()

    page.on("dialog", on_dialog)
    page.goto(f"{blog_url}/manage/newpost/", wait_until="domcontentloaded")

    if "/auth/login" in page.url:
        raise PublishError(
            "카카오 로그인 세션이 만료되었습니다.\n"
            "  → python src/login.py 를 실행해 다시 로그인해주세요."
        )

    page.wait_for_timeout(EDITOR_BOOT_MS)

    try:
        page.wait_for_selector(selectors.TITLE_INPUT, timeout=10000)
    except PlaywrightTimeout:
        raise _fail(page, "에디터 로딩", "에디터가 로딩되지 않았습니다.") from None


def fill_title(page: Page, title: str) -> None:
    page.fill(selectors.TITLE_INPUT, title)


def upload_images(page: Page, images: list[dict]) -> list[str]:
    """이미지를 순서대로 업로드하고 티스토리가 만든 마크업을 수집한다."""
    if not images:
        return []

    markups: list[str] = []
    for index, image in enumerate(images):
        before = _figures(page)

        try:
            page.click(selectors.ATTACH_DROPDOWN)
            page.wait_for_timeout(800)
            photo_item = page.get_by_text(selectors.ATTACH_PHOTO_ITEM, exact=True).first
            with page.expect_file_chooser(timeout=10000) as chooser_info:
                photo_item.click()
            chooser_info.value.set_files(image["path"])
        except Exception as error:
            raise _fail(
                page,
                f"이미지첨부-{index}",
                f"{index + 1}번째 이미지 첨부창을 열지 못했습니다: {error}",
            ) from error

        page.wait_for_timeout(UPLOAD_WAIT_MS)

        after = _figures(page)
        if len(after) <= len(before):
            raise _fail(
                page,
                f"이미지업로드-{index}",
                f"{index + 1}번째 이미지 업로드가 확인되지 않았습니다: {image['path']}",
            )

        markups.append(_apply_alt(after[len(before)], image.get("alt", "")))
        print(f"    - {index + 1}/{len(images)} 업로드 완료: {Path(image['path']).name}")

    return markups


_FIGURE_PATTERN = re.compile(r"<figure[^>]*>.*?</figure>", re.S | re.I)


def _figures(page: Page) -> list[str]:
    """현재 본문에 있는 <figure> 블록 목록 (등장 순서)."""
    try:
        return _FIGURE_PATTERN.findall(body_frame(page).inner_html())
    except Exception:
        return []


def _apply_alt(markup: str, alt: str) -> str:
    """접근성과 검색 노출을 위해 alt를 채워 넣는다."""
    if not alt or "alt=" in markup:
        return markup
    safe = alt.replace('"', "&quot;")
    return markup.replace("<img ", f'<img alt="{safe}" ', 1)


def set_body(page: Page, body_html: str) -> None:
    """TinyMCE에 본문을 통째로 주입한다.

    DOM 직접 수정이나 HTML 모드 CodeMirror.setValue는 티스토리가 변경을 인식하지
    못해 내용이 날아간다 (실측 확인). 반드시 에디터 API를 쓴다.
    """
    result = page.evaluate(
        """
        (html) => {
          const tm = window.tinymce;
          if (!tm) return 'no-tinymce';
          const editor = tm.activeEditor || (tm.editors && tm.editors[0]);
          if (!editor) return 'no-editor';
          editor.setContent(html);
          editor.fire('change');
          return 'ok';
        }
        """,
        body_html,
    )
    if result != "ok":
        raise _fail(page, "본문주입", f"본문을 주입하지 못했습니다 (사유: {result}).")

    page.wait_for_timeout(1500)

    if not body_frame(page).inner_html().strip():
        raise _fail(page, "본문확인", "본문 주입 후에도 에디터가 비어 있습니다.")


def set_tags(page: Page, tags: list[str]) -> None:
    if not tags:
        return
    field = page.locator(selectors.TAG_INPUT).first
    if field.count() == 0:
        print("  [경고] 태그 입력란을 찾지 못해 태그를 건너뜁니다.")
        return
    for tag in tags:
        field.click()
        field.type(tag, delay=30)
        field.press("Enter")
        page.wait_for_timeout(250)


def publish(
    page: Page, visibility: str, draft: bool, blog_url: str, slug: str = ""
) -> str:
    page.click(selectors.PUBLISH_LAYER_OPEN)
    page.wait_for_timeout(2000)

    radio = page.locator(selectors.VISIBILITY.get(visibility, selectors.VISIBILITY["public"]))
    if radio.count() == 0:
        raise _fail(
            page,
            "발행레이어",
            "발행 레이어가 열리지 않았습니다 (제목이나 본문이 비었을 수 있습니다).",
        )
    try:
        radio.first.check()
    except Exception:
        print(f"  [경고] 공개설정({visibility}) 선택 실패 — 기본값으로 진행합니다.")

    # 원고에 slug를 주면 짧은 영문 주소로 바꾼다.
    # 단, 블로그 '글 주소' 설정이 숫자형이면 이 입력란이 disabled라 지정할 수 없다.
    if slug:
        field = page.locator(selectors.URL_SLUG_INPUT).first
        if field.count() == 0:
            print(f"  [경고] URL 입력란이 없어 슬러그({slug})를 건너뜁니다.")
        elif field.is_disabled():
            print(
                f"  [안내] 슬러그({slug})를 적용하지 못했습니다. 이 블로그의 글 주소가"
                " 숫자형이라 URL이 잠겨 있습니다.\n"
                "         티스토리 관리 → 블로그 → '글 주소'를 '문자'로 바꾸면 적용됩니다."
            )
        else:
            try:
                field.fill(slug)
            except Exception as error:
                print(f"  [경고] 슬러그({slug}) 지정 실패 — 기본값으로 진행합니다: {error}")

    if draft:
        capture = _snapshot(page, "draft-미리보기")
        print(f"  [--draft] 발행하지 않고 멈춥니다. 화면: {capture}")
        return "(미발행)"

    page.click(selectors.PUBLISH_CONFIRM)

    # 발행이 실제로 끝나야 글쓰기 화면(newpost)을 벗어난다.
    # 여기서 확인하지 않으면 실패한 글이 '성공'으로 기록되어 영영 재시도되지 않는다
    # (2026-07-30 사고: state.json 24건 중 11건이 실제로는 발행되지 않았다).
    try:
        page.wait_for_url(
            re.compile(r"/manage/posts|" + re.escape(blog_url) + r"/\d+"),
            timeout=40000,
        )
    except PlaywrightTimeout:
        # 티스토리는 하루 15건까지만 공개 발행을 허용한다. 이건 고쳐서 될 문제가 아니라
        # 오늘 분량이 끝났다는 뜻이므로, 남은 글은 내일 자동으로 이어서 올린다.
        if any(_DAILY_LIMIT_MARK in message for message in DIALOG_LOG):
            _dump_debug(page, "일일한도")
            raise DailyLimitReached(
                "티스토리 일일 공개 발행 한도(15건)에 도달했습니다.\n"
                "  → 오늘은 더 올릴 수 없습니다. 남은 글은 내일 자동으로 이어서 발행됩니다."
            ) from None
        raise _fail(
            page,
            "발행확인",
            "발행 버튼을 눌렀지만 글이 등록되지 않았습니다 "
            f"(현재 위치: {page.url}).{_dialog_hint()}",
        ) from None

    if "/manage/newpost" in page.url:
        raise _fail(page, "발행확인", "발행 후에도 글쓰기 화면에 머물러 있습니다.")

    return page.url


# ---------------------------------------------------------------- 엔트리포인트


def run(manuscript_path: Path, draft: bool, headed: bool) -> int:
    config = load_config()
    blog_url = config["blog_url"].rstrip("/")

    try:
        manuscript = load_manuscript(manuscript_path)
    except ManuscriptError as error:
        print(f"[실패] {error}")
        return 1

    images = collect_images(manuscript)
    body_template = render_html(manuscript)
    tags = manuscript.get("tags") or config.get("default_tags", [])
    visibility = manuscript.get("visibility") or config.get("default_visibility", "public")

    print(f"제목  : {manuscript['title']}")
    print(f"이미지: {len(images)}장 / 태그: {len(tags)}개 / 공개: {visibility}")

    with open_context(headless=not headed) as context:
        page = context.pages[0] if context.pages else context.new_page()
        try:
            print("[1/5] 에디터 여는 중...")
            open_editor(page, blog_url)

            print("[2/5] 제목 입력...")
            fill_title(page, manuscript["title"])

            print(f"[3/5] 이미지 {len(images)}장 업로드...")
            markups = upload_images(page, images)

            print("[4/5] 본문 주입...")
            body_html = body_template
            for index, markup in enumerate(markups):
                body_html = body_html.replace(IMAGE_PLACEHOLDER.format(index=index), markup)
            set_body(page, body_html)
            set_tags(page, tags)

            print("[5/5] 발행...")
            final_url = publish(
                page, visibility, draft, blog_url, manuscript.get("slug", "")
            )

        except DailyLimitReached as error:
            # 고칠 수 있는 실패가 아니라 '오늘 분량 끝'이다.
            # 종료코드 2로 알려서 배치가 남은 글 시도를 멈추게 한다.
            print(f"\n[중단] {error}")
            return 2
        except PublishError as error:
            print(f"\n[실패] {error}")
            return 1
        except Exception as error:  # noqa: BLE001 - 최상위에서 진단 정보를 남긴다
            _dump_debug(page, "예상치못한오류")
            print(f"\n[실패] 예상치 못한 오류: {type(error).__name__}: {error}")
            print(f"  진단 파일: {DEBUG_DIR}")
            return 1

    # 원본 네이버 글을 기록해 다음 동기화에서 중복 발행되지 않게 한다.
    # (실패하면 기록하지 않으므로 다음 실행 때 자동으로 재시도된다)
    log_no = manuscript.get("source_log_no")
    if log_no and not draft:
        sync_state.mark_published(str(log_no), manuscript["title"], final_url)
        print(f"  발행 이력 기록: naver {log_no}")

    print(f"\n[완료] {final_url}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="티스토리 자동 발행")
    parser.add_argument("manuscript", type=Path, help="원고 JSON 경로")
    parser.add_argument("--draft", action="store_true", help="발행하지 않고 직전까지만")
    parser.add_argument("--headed", action="store_true", help="브라우저 창을 띄운다")
    args = parser.parse_args()
    return run(args.manuscript, args.draft, args.headed)


if __name__ == "__main__":
    raise SystemExit(main())
