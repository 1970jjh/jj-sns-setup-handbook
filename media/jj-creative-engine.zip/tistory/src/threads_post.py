"""스레드(Threads) 발행 — 티스토리 글을 인사이트 요약 + 링크로 올린다.

    python src/threads_post.py posts/threads/<logNo>.json
    python src/threads_post.py posts/threads/<logNo>.json --dry-run

원고 JSON 형식:
{
  "source_log_no": "224327302858",
  "text": "500자 이내 본문 (마지막 줄에 티스토리 링크)",
  "image_url": "https://jj-aiedu.vercel.app/training/224327302858.png"   # 선택
}

스레드는 2단계로 발행한다: 컨테이너 생성 → 발행.
이미지 URL은 **외부에서 접근 가능한 공개 주소**여야 한다
(홈페이지에 올린 썸네일 public/training/*.png 을 그대로 쓴다).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src import threads_auth  # noqa: E402
from src import sync_state  # noqa: E402

API_BASE = "https://graph.threads.net/v1.0"
TEXT_LIMIT = 500          # 스레드 본문 상한
PUBLISH_WAIT_SECONDS = 5  # 컨테이너 처리 대기 (이미지 포함 시 필요)


class ThreadsError(RuntimeError):
    """스레드 발행 실패."""


def _post(path: str, params: dict) -> dict:
    body = urllib.parse.urlencode(params).encode()
    request = urllib.request.Request(f"{API_BASE}/{path}", data=body, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=40) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as error:
        detail = error.read().decode(errors="ignore")[:400]
        raise ThreadsError(f"HTTP {error.code}: {detail}") from None


def _permalink(post_id: str, access_token: str) -> str | None:
    """발행된 글의 실제 주소를 조회한다.

    🔴 post_id 로 주소를 조립하면 안 된다 (2026-08-05 실측).
    threads_publish 가 돌려주는 것은 긴 숫자 media_id 이고,
    /post/ 뒤에 오는 것은 전혀 다른 shortcode 다.
    숫자로 만든 주소는 열면 '페이지는 길을 잃었습니다' 가 뜬다.
    (instagram_post.py 가 같은 이유로 permalink 를 조회한다)
    """
    query = urllib.parse.urlencode({"fields": "permalink", "access_token": access_token})
    try:
        with urllib.request.urlopen(f"{API_BASE}/{post_id}?{query}", timeout=30) as response:
            return json.loads(response.read().decode()).get("permalink")
    except Exception as error:  # 조회 실패가 발행 자체를 되돌리지는 않는다
        print(f"  [경고] permalink 조회 실패 ({type(error).__name__}) — media_id 로 기록합니다")
        return None


def validate(manuscript: dict) -> str:
    text = (manuscript.get("text") or "").strip()
    if not text:
        raise ThreadsError("text가 비어 있습니다.")
    if len(text) > TEXT_LIMIT:
        raise ThreadsError(
            f"본문이 {len(text)}자입니다. 스레드는 {TEXT_LIMIT}자까지만 됩니다."
        )
    return text


def publish(manuscript: dict, dry_run: bool = False) -> str:
    text = validate(manuscript)
    image_url = (manuscript.get("image_url") or "").strip()

    print(f"본문 {len(text)}자 / 이미지: {'있음' if image_url else '없음'}")
    print("-" * 60)
    print(text)
    print("-" * 60)

    if dry_run:
        print("[--dry-run] 실제로 올리지 않았습니다.")
        return "(미발행)"

    token = threads_auth.refresh_if_needed()
    if token is None:
        raise ThreadsError(
            "스레드 토큰이 없습니다.\n"
            "  → python src/threads_auth.py 를 먼저 실행해 인증해주세요."
        )

    user_id = token["user_id"]
    access_token = token["access_token"]

    # 1) 컨테이너 생성
    params = {
        "media_type": "IMAGE" if image_url else "TEXT",
        "text": text,
        "access_token": access_token,
    }
    if image_url:
        params["image_url"] = image_url

    container = _post(f"{user_id}/threads", params)
    creation_id = container.get("id")
    if not creation_id:
        raise ThreadsError(f"컨테이너 생성 실패: {container}")
    print(f"  컨테이너 생성: {creation_id}")

    # 이미지가 있으면 서버가 내려받아 처리할 시간이 필요하다.
    if image_url:
        time.sleep(PUBLISH_WAIT_SECONDS)

    # 2) 발행
    published = _post(
        f"{user_id}/threads_publish",
        {"creation_id": creation_id, "access_token": access_token},
    )
    post_id = published.get("id")
    if not post_id:
        raise ThreadsError(f"발행 실패: {published}")

    url = _permalink(post_id, access_token) or f"https://www.threads.net/@YOUR_INSTAGRAM_ID/post/{post_id}"

    # 원본 네이버 글을 기록해 다음 동기화에서 같은 글을 두 번 올리지 않게 한다.
    log_no = manuscript.get("source_log_no")
    if log_no:
        sync_state.mark_shared(str(log_no), url, channel="threads")
        print(f"  스레드 이력 기록: naver {log_no}")

    return url


def main() -> int:
    parser = argparse.ArgumentParser(description="스레드 발행")
    parser.add_argument("manuscript", type=Path)
    parser.add_argument("--dry-run", action="store_true", help="내용만 확인하고 올리지 않음")
    args = parser.parse_args()

    try:
        data = json.loads(args.manuscript.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as error:
        print(f"[실패] 원고를 읽지 못했습니다: {error}")
        return 1

    try:
        url = publish(data, args.dry_run)
    except ThreadsError as error:
        print(f"\n[실패] {error}")
        return 1

    print(f"\n[완료] {url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
