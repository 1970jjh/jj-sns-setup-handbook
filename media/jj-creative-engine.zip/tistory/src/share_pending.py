"""SNS에 아직 안 올라간 티스토리 글 목록을 뽑는다 (스레드·인스타 공용).

    python src/share_pending.py threads   --limit 2
    python src/share_pending.py instagram --limit 1
    python src/share_pending.py youtube   --limit 1

각 항목에 원고를 쓸 때 필요한 정보를 함께 준다:
  - 티스토리 URL (스레드는 본문 링크, 인스타는 프로필 링크 안내용)
  - 썸네일 공개 URL
  - 원고 JSON 경로 (인사이트를 뽑아낼 원본)
  - 현장 사진 장수 (인스타 카드덱·쇼츠 씬 구성 가능 여부 판단)

비공개 티스토리 글은 방문자가 못 보므로 대상에서 제외한다.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src import sync_state  # noqa: E402

SITE_BASE = "https://jj-aiedu.vercel.app"
DATA_FILE = PROJECT_ROOT.parent / "jj-aiedu" / "src" / "data" / "trainingLog.ts"

# 인스타 캐러셀·유튜브 쇼츠 모두 실사와 생성을 5:5로 섞는다.
# 최소 이만큼의 현장 사진이 있어야 덱/씬 구성이 된다.
MIN_PHOTOS = {"instagram": 3, "youtube": 3}


def tistory_url(log_no: str) -> str:
    if not DATA_FILE.is_file():
        return ""
    try:
        text = DATA_FILE.read_text(encoding="utf-8")
    except OSError:
        return ""
    found = re.search(rf'id:\s*"{log_no}".*?url:\s*"([^"]+)"', text, re.S)
    return found.group(1) if found else ""


def manuscript_path(log_no: str) -> str:
    for path in (PROJECT_ROOT / "posts").rglob(f"*{log_no}*.json"):
        if not {"threads", "instagram"} & set(path.parts):
            return str(path)
    return ""


def photo_count(log_no: str, *, include_screenshots: bool = False) -> int:
    """네이버 원문에서 쓸 수 있는 이미지 장수.

    기본은 현장 사진(is_photo)만 센다. include_screenshots면 앱 화면 캡처까지 포함한다.
    """
    source = PROJECT_ROOT / "work" / log_no / "source.json"
    if not source.is_file():
        return 0
    try:
        blocks = json.loads(source.read_text(encoding="utf-8"))["blocks"]
    except (json.JSONDecodeError, KeyError, OSError):
        return 0
    return sum(
        1
        for block in blocks
        if block.get("type") == "image"
        and (include_screenshots or block.get("is_photo"))
        and Path(block.get("path", "")).is_file()
    )


def is_public(url: str) -> bool:
    """방문자가 실제로 볼 수 있는 글인지 확인한다 (비공개는 403)."""
    if not url:
        return False
    request = urllib.request.Request(
        url, headers={"User-Agent": "Mozilla/5.0"}, method="HEAD"
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return response.status == 200
    except Exception:
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description="SNS 미발행 글 조회")
    parser.add_argument("channel", choices=("threads", "instagram", "youtube"))
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()

    candidates = sync_state.pending_share(args.channel)
    pending, skipped_private, skipped_photos = [], 0, 0

    for item in candidates:
        log_no = item["log_no"]
        url = tistory_url(log_no)
        if not is_public(url):
            skipped_private += 1
            continue

        photos = photo_count(log_no)
        assets = photo_count(log_no, include_screenshots=True)
        # 현장 사진이 없어도 앱 화면 같은 원문 자산이 충분하면 쓸 수 있다.
        # 생성 이미지만으로 만드는 것을 막는 게 이 기준의 목적이기 때문이다.
        if max(photos, assets) < MIN_PHOTOS.get(args.channel, 0):
            skipped_photos += 1
            continue

        pending.append({**item, "url": url, "photos": photos, "assets": assets})
        if args.limit and len(pending) >= args.limit:
            break

    notes = []
    if skipped_private:
        notes.append(f"비공개 {skipped_private}건")
    if skipped_photos:
        notes.append(f"현장사진 부족 {skipped_photos}건")
    if notes:
        print(f"(제외: {', '.join(notes)})\n")

    if not pending:
        print("대상 없음")
        return 0

    print(f"{args.channel} 미발행 {len(pending)}건\n")
    for order, item in enumerate(pending, 1):
        log_no = item["log_no"]
        thumb = PROJECT_ROOT / "thumbs" / f"{log_no}.png"
        print(f"[{order}] {log_no}")
        print(f"    제목      : {item['title']}")
        print(f"    티스토리  : {item['url']}")
        if thumb.is_file():
            print(f"    썸네일    : {SITE_BASE}/training/{log_no}.png")
        if args.channel in MIN_PHOTOS:
            if item["photos"]:
                print(f"    현장사진  : {item['photos']}장 사용 가능")
            else:
                print(f"    현장사진  : 0장 — 앱 화면 캡처 {item['assets']}장으로 구성 "
                      f"(cards_build.py --with-screenshots)")
        print(f"    원고      : {manuscript_path(log_no) or '(없음)'}")
        print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
