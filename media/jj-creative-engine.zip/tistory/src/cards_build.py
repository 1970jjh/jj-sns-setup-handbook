"""인스타 카드뉴스 이미지를 모아 홈페이지에 올릴 수 있게 준비한다.

    python src/cards_build.py <logNo> --photos 3 5 --cards cards/01.jpg cards/02.jpg ...

하는 일:
  1) 생성 카드(image-flow 산출물)와 네이버 원문 현장 사진을 정해진 순서로 모은다
  2) 인스타 규격에 맞게 정사각(1080x1080) JPEG로 변환한다
  3) jj-aiedu/public/cards/<logNo>/ 로 복사한다 (배포하면 공개 URL이 된다)

인스타는 캐러셀의 모든 이미지가 **같은 비율**이어야 잘리지 않는다. 그래서 전부 1:1로 맞춘다.
현장 사진은 잘라내지 않고 여백을 넣어 담는다(letterbox) — 사람 얼굴이 잘리면 안 되기 때문.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SITE_ROOT = PROJECT_ROOT.parent / "jj-aiedu"
CARD_SIZE = 1080
JPEG_QUALITY = 88
BACKGROUND = (255, 255, 255)


def load_photos(log_no: str, *, include_screenshots: bool = False) -> list[Path]:
    """네이버 원문 이미지를 등장 순서대로 돌려준다.

    기본은 현장 사진(is_photo)만. `include_screenshots=True`면 앱 화면·대시보드 캡처까지
    포함한다 — 바이브코딩 과정처럼 **수강생 결과물이 곧 스크린샷**인 글은 그것이 실제 자산이다.
    (is_photo는 색상 다양성 휴리스틱이라 위성지도 캡처를 사진으로 오판하기도 한다.)
    """
    source = PROJECT_ROOT / "work" / log_no / "source.json"
    if not source.is_file():
        return []
    try:
        blocks = json.loads(source.read_text(encoding="utf-8"))["blocks"]
    except (json.JSONDecodeError, KeyError, OSError):
        return []

    photos = []
    for block in blocks:
        if block.get("type") != "image":
            continue
        if not include_screenshots and not block.get("is_photo"):
            continue
        path = Path(block.get("path", ""))
        if path.is_file():
            photos.append(path)
    return photos


def to_square(source: Path, target: Path) -> None:
    """1080x1080 JPEG로 변환한다. 잘라내지 않고 여백을 넣는다."""
    from PIL import Image

    with Image.open(source) as image:
        image = image.convert("RGB")
        image.thumbnail((CARD_SIZE, CARD_SIZE), Image.LANCZOS)
        canvas = Image.new("RGB", (CARD_SIZE, CARD_SIZE), BACKGROUND)
        canvas.paste(
            image,
            ((CARD_SIZE - image.width) // 2, (CARD_SIZE - image.height) // 2),
        )
        target.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(target, "JPEG", quality=JPEG_QUALITY, optimize=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="인스타 카드덱 준비")
    parser.add_argument("log_no")
    parser.add_argument("--cards", nargs="*", default=[],
                        help="생성 카드 이미지 경로 (순서대로)")
    parser.add_argument("--photo-slots", nargs="*", type=int, default=[],
                        help="현장 사진을 끼워 넣을 위치 (1부터, 최종 순번 기준)")
    parser.add_argument("--with-screenshots", action="store_true",
                        help="앱 화면·대시보드 캡처도 실사 슬롯에 쓴다 (현장 사진이 없는 글)")
    parser.add_argument("--photo-count", type=int, default=2,
                        help="사용할 현장 사진 장수")
    args = parser.parse_args()

    cards = [Path(p) for p in args.cards]
    missing = [str(p) for p in cards if not p.is_file()]
    if missing:
        print("[실패] 카드 이미지를 찾을 수 없습니다:")
        for path in missing:
            print(f"  - {path}")
        return 1

    photos = load_photos(
        args.log_no, include_screenshots=args.with_screenshots
    )[: args.photo_count]
    if args.photo_slots and len(args.photo_slots) != len(photos):
        print(
            f"[경고] 사진 슬롯 {len(args.photo_slots)}개 / 실제 사진 {len(photos)}장 — "
            "가능한 만큼만 배치합니다."
        )

    # 최종 순서 조립: 지정한 슬롯에 사진을, 나머지는 생성 카드를 채운다.
    total = len(cards) + len(photos)
    slots = {position for position in args.photo_slots if 1 <= position <= total}
    if not slots:
        slots = set()

    ordered: list[Path] = []
    card_queue, photo_queue = list(cards), list(photos)
    for position in range(1, total + 1):
        if position in slots and photo_queue:
            ordered.append(photo_queue.pop(0))
        elif card_queue:
            ordered.append(card_queue.pop(0))
        elif photo_queue:
            ordered.append(photo_queue.pop(0))

    if not 2 <= len(ordered) <= 10:
        print(f"[실패] 최종 {len(ordered)}장입니다. 캐러셀은 2~10장이어야 합니다.")
        return 1

    out_dir = SITE_ROOT / "public" / "cards" / args.log_no
    if out_dir.exists():
        for stale in out_dir.glob("*.jpg"):
            stale.unlink()

    urls = []
    for order, source in enumerate(ordered, 1):
        target = out_dir / f"{order:02d}.jpg"
        to_square(source, target)
        urls.append(f"https://jj-aiedu.vercel.app/cards/{args.log_no}/{order:02d}.jpg")
        kind = "현장사진" if source in photos else "생성카드"
        print(f"  {order:2}. [{kind}] {source.name} → {target.name}")

    print(f"\n[완료] {len(urls)}장 준비 → {out_dir}")
    print("\n원고 JSON의 images 에 넣을 URL:")
    print(json.dumps(urls, ensure_ascii=False, indent=1))
    print("\n※ 배포해야 공개 URL이 됩니다: python src/site_sync.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
