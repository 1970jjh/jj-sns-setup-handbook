"""원고 여러 건을 순차 발행한다.

    python src/publish_batch.py posts/backfill            # 폴더 안의 *.json 전부
    python src/publish_batch.py posts/backfill --gap 180  # 글 사이 간격(초)

새 블로그에 글을 한꺼번에 쏟으면 검색엔진이 스팸으로 볼 수 있어 기본 간격을 둔다.
한 건이 실패해도 나머지는 계속 진행하고, 마지막에 결과를 정리해 보여준다.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.publish import run  # noqa: E402
from src import sync_state  # noqa: E402

DEFAULT_GAP_SECONDS = 90


def already_published(path: Path) -> bool:
    """이미 발행된 글인지 state.json으로 확인한다.

    발행을 여러 프로세스로 병렬 실행할 때 같은 글이 두 번 올라가는 것을 막는다.
    """
    try:
        log_no = json.loads(path.read_text(encoding="utf-8")).get("source_log_no")
    except (json.JSONDecodeError, OSError):
        return False
    return bool(log_no) and sync_state.is_published(str(log_no))


def main() -> int:
    parser = argparse.ArgumentParser(description="티스토리 일괄 발행")
    parser.add_argument("folder", type=Path, help="원고 JSON들이 든 폴더")
    parser.add_argument("--gap", type=int, default=DEFAULT_GAP_SECONDS,
                        help=f"글 사이 대기 초 (기본 {DEFAULT_GAP_SECONDS})")
    parser.add_argument("--headed", action="store_true")
    args = parser.parse_args()

    manuscripts = sorted(args.folder.glob("*.json"))
    if not manuscripts:
        print(f"[실패] {args.folder} 에 원고 JSON이 없습니다.")
        return 1

    print(f"발행 대상 {len(manuscripts)}건 (간격 {args.gap}초)\n")
    results: list[tuple[str, bool]] = []

    for order, path in enumerate(manuscripts, 1):
        print("=" * 66)
        print(f"[{order}/{len(manuscripts)}] {path.name}")
        print("=" * 66)
        if already_published(path):
            print("  이미 발행된 글입니다 — 건너뜁니다.")
            results.append((path.name, True))
            continue
        try:
            code = run(path, draft=False, headed=args.headed)
        except Exception as error:  # noqa: BLE001 - 한 건 실패로 전체를 멈추지 않는다
            print(f"[실패] {type(error).__name__}: {error}")
            code = 1

        if code == 2:
            # 티스토리 일일 한도. 더 시도해봐야 전부 실패하므로 여기서 멈춘다.
            print("\n[중단] 오늘 발행 한도에 도달했습니다. 남은 글은 내일 이어서 올립니다.")
            remaining = [p.name for p in manuscripts[order - 1:]]
            print(f"  내일 대상 {len(remaining)}건")
            break

        results.append((path.name, code == 0))

        if order < len(manuscripts) and args.gap:
            print(f"\n  다음 글까지 {args.gap}초 대기...\n")
            time.sleep(args.gap)

    succeeded = [name for name, ok in results if ok]
    failed = [name for name, ok in results if not ok]

    print("\n" + "=" * 66)
    print(f"성공 {len(succeeded)}건 / 실패 {len(failed)}건")
    for name in failed:
        print(f"  [실패] {name}")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
