"""스레드 / 인스타 액세스 토큰을 안전하게 저장한다.

    python src/set_token.py            # 스레드 (기본)
    python src/set_token.py instagram  # 인스타

Meta 개발자 콘솔의 '사용자 토큰 생성기'에서 받은 장기 토큰을 붙여넣으면
검증(계정 확인) 후 .auth/threads.json 에 저장한다.
입력값은 화면에 표시되지 않으며, user_id는 API로 자동 조회한다.

이 방식을 쓰면 OAuth 리다이렉트(및 리다이렉트 URI 등록)가 아예 필요 없다.
"""

from __future__ import annotations

import getpass
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
# 채널별 저장 위치와 검증 엔드포인트
CHANNELS = {
    "threads": {
        "path": PROJECT_ROOT / ".auth" / "threads.json",
        "verify": "https://graph.threads.net/v1.0/me",
        "fields": "id,username",
        "label": "스레드",
    },
    "instagram": {
        "path": PROJECT_ROOT / ".auth" / "instagram.json",
        "verify": "https://graph.instagram.com/v21.0/me",
        "fields": "id,username",
        "label": "인스타",
    },
}
KST = timezone(timedelta(hours=9))

# 생성기에서 받는 토큰은 장기 토큰(60일)이다.
DEFAULT_VALID_DAYS = 60


def verify(token: str, channel: dict) -> dict | None:
    """토큰이 유효한지 확인하고 계정 정보를 돌려준다."""
    url = channel["verify"] + "?" + urllib.parse.urlencode(
        {"fields": channel["fields"], "access_token": token}
    )
    try:
        with urllib.request.urlopen(url, timeout=25) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as error:
        detail = error.read().decode(errors="ignore")[:200]
        print(f"[실패] 토큰이 유효하지 않습니다 (HTTP {error.code}).")
        print(f"  응답: {detail}")
        return None
    except Exception as error:
        print(f"[실패] 확인 중 오류: {error}")
        return None


def main() -> int:
    name = sys.argv[1] if len(sys.argv) > 1 else "threads"
    if name not in CHANNELS:
        print(f"사용법: python src/set_token.py [{' | '.join(CHANNELS)}]")
        return 1
    channel = CHANNELS[name]

    print(f"Meta 개발자 콘솔에서 받은 {channel['label']} 액세스 토큰을")
    print("붙여넣고 Enter를 누르세요.")
    print("(입력 내용은 화면에 표시되지 않습니다)\n")

    token = getpass.getpass("토큰: ").strip()
    if not token:
        print("[중단] 입력이 비어 있습니다.")
        return 1
    if len(token) < 50:
        print(f"[중단] 너무 짧습니다({len(token)}자). 토큰이 아닌 것 같습니다.")
        return 1

    print("\n토큰을 확인하는 중...")
    profile = verify(token, channel)
    if profile is None:
        return 1

    record = {
        "access_token": token,
        "user_id": str(profile["id"]),
        "expires_at": (datetime.now(KST) + timedelta(days=DEFAULT_VALID_DAYS)).isoformat(
            timespec="seconds"
        ),
    }
    token_path = channel["path"]
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(
        json.dumps(record, ensure_ascii=False, indent=1), encoding="utf-8"
    )

    print(f"[완료] 저장했습니다: {token_path}")
    print(f"  계정   : @{profile.get('username')}")
    print(f"  user_id: {profile['id']}")
    print(f"  만료   : {record['expires_at']} (자동 갱신됨)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
