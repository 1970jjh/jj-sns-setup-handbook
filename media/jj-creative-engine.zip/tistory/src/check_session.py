"""카카오 로그인 세션이 살아있는지 확인한다 (자동화 선행 점검용).

    python src/check_session.py

종료코드: 0 = 정상, 2 = 재로그인 필요, 1 = 확인 실패

카카오 세션은 몇 시간 만에 끊기는 일이 잦다(실측: 13시 로그인 → 20시 만료).
자동화가 조용히 실패하지 않도록 맨 앞에서 확인하고, 끊겼으면 화면 알림을 띄운다.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.session import load_config, open_context  # noqa: E402

NOTIFY_TITLE = "티스토리 자동화 - 재로그인 필요"
NOTIFY_BODY = (
    "카카오 로그인 세션이 만료되어 오늘 자동 발행이 중단됐습니다.\\n\\n"
    "아래 명령을 실행해 다시 로그인해주세요:\\n"
    "cd C:\\\\Users\\\\ksajh\\\\claude-app\\\\tistory\\n"
    "python src\\\\login.py"
)


def notify(title: str, body: str) -> None:
    """윈도우 알림 창을 띄운다. 로그 파일만 남기면 아무도 못 본다."""
    script = (
        "Add-Type -AssemblyName PresentationFramework;"
        f"[System.Windows.MessageBox]::Show('{body}','{title}','OK','Warning')"
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script],
            capture_output=True, timeout=60,
        )
    except Exception:
        pass  # 알림 실패가 본 작업을 막지는 않게 한다


def main() -> int:
    config = load_config()
    blog_url = config["blog_url"].rstrip("/")

    try:
        with open_context(headless=True) as context:
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(f"{blog_url}/manage", wait_until="domcontentloaded")
            logged_in = "/auth/login" not in page.url
    except Exception as error:
        print(f"[실패] 세션 확인 중 오류: {error}")
        return 1

    if logged_in:
        print("[정상] 카카오 세션이 살아있습니다.")
        return 0

    print("[중단] 카카오 세션이 만료되었습니다. python src/login.py 로 다시 로그인해주세요.")
    notify(NOTIFY_TITLE, NOTIFY_BODY)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
