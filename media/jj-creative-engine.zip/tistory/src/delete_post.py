"""티스토리 글 삭제 (제목 정확 일치로 대상을 특정한다).

    python src/delete_post.py "삭제할 글 제목"

되돌릴 수 없는 작업이므로 제목이 정확히 일치하는 글이 1건일 때만 지운다.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import load_config, open_context  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"

# 글 목록에서 제목 텍스트와 행 체크박스를 짝지어 찾는다.
_FIND_ROW = """
(title) => {
  const boxes = Array.from(document.querySelectorAll('input[type=checkbox]'));
  const hits = [];
  for (const box of boxes) {
    const row = box.closest('li, tr, div[class*=item], div[class*=list]');
    if (!row) continue;
    const text = (row.innerText || '').trim();
    if (text.includes(title)) hits.push({ text: text.slice(0, 80) });
  }
  return hits;
}
"""

_CHECK_ROW = """
(title) => {
  const boxes = Array.from(document.querySelectorAll('input[type=checkbox]'));
  for (const box of boxes) {
    const row = box.closest('li, tr, div[class*=item], div[class*=list]');
    if (!row) continue;
    if ((row.innerText || '').includes(title)) { box.click(); return true; }
  }
  return false;
}
"""


def main() -> int:
    if len(sys.argv) < 2:
        print('사용법: python src/delete_post.py "글 제목"')
        return 1
    title = sys.argv[1]

    config = load_config()
    blog_url = config["blog_url"].rstrip("/")
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)

    with open_context(headless=True) as context:
        page = context.pages[0] if context.pages else context.new_page()
        messages: list[str] = []

        def on_dialog(dialog):
            messages.append(dialog.message)
            print(f"  [확인창] {dialog.message[:70]}")
            dialog.accept()  # 삭제 확인

        page.on("dialog", on_dialog)
        page.goto(f"{blog_url}/manage/posts/", wait_until="domcontentloaded")
        if "/auth/login" in page.url:
            print("[실패] 로그인이 필요합니다. python src/login.py 를 실행하세요.")
            return 1
        page.wait_for_timeout(4000)

        hits = page.evaluate(_FIND_ROW, title)
        if len(hits) != 1:
            print(f"[중단] 제목 '{title}' 에 해당하는 글이 {len(hits)}건입니다. 1건일 때만 삭제합니다.")
            for hit in hits:
                print(f"  - {hit['text']}")
            return 1
        print(f"삭제 대상: {hits[0]['text'][:60]}")

        if not page.evaluate(_CHECK_ROW, title):
            print("[실패] 대상 행을 선택하지 못했습니다.")
            return 1
        page.wait_for_timeout(1200)

        # .btn_opt가 여러 개(제목/변경/보기/비공개)라 '변경' 텍스트로 특정해야 한다.
        change_btn = page.locator("button.btn_opt", has_text="변경").first
        if change_btn.count() == 0:
            page.screenshot(path=str(DEBUG_DIR / "fail-change-btn.png"), full_page=True)
            print("[실패] '변경' 버튼을 찾지 못했습니다.")
            return 1
        change_btn.click(force=True)
        page.wait_for_timeout(1500)

        # 메뉴 항목은 <label class="lab_btn">삭제<input type="button"></label> 구조다.
        # 안쪽 input은 크기가 0이라 클릭이 먹지 않으므로 label을 눌러야 한다.
        delete_item = page.locator("ul.list_opt label.lab_btn").filter(has_text="삭제").first
        if delete_item.count() == 0:
            page.screenshot(path=str(DEBUG_DIR / "fail-delete-menu.png"), full_page=True)
            print(f"[실패] 삭제 메뉴를 찾지 못했습니다. {DEBUG_DIR / 'fail-delete-menu.png'}")
            return 1
        delete_item.click(force=True)
        page.wait_for_timeout(5000)

        # 목록을 다시 읽어 실제로 사라졌는지 확인한다.
        page.goto(f"{blog_url}/manage/posts/", wait_until="domcontentloaded")
        page.wait_for_timeout(3500)
        remaining = page.evaluate(_FIND_ROW, title)
        page.screenshot(path=str(DEBUG_DIR / "after-delete.png"), full_page=True)
        if remaining:
            print(f"[실패] 삭제 후에도 글이 남아 있습니다 ({len(remaining)}건).")
            return 1

    print("[완료] 삭제되었습니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
