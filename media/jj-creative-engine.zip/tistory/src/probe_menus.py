"""에디터의 드롭다운/레이어를 실제로 열어 내부 요소를 확인한다.

셀렉터 확정용 조사 스크립트. 발행 버튼은 절대 누르지 않는다.

    python src/probe_menus.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import load_config, open_context  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"

_VISIBLE_SCAN = """
() => {
  const out = [];
  const nodes = document.querySelectorAll(
    'button, a, input, label, [role="menuitem"], [role="button"], li'
  );
  for (const el of nodes) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const style = getComputedStyle(el);
    if (style.visibility === 'hidden' || style.display === 'none') continue;
    out.push({
      tag: el.tagName.toLowerCase(),
      id: el.id || null,
      cls: (typeof el.className === 'string') ? el.className.slice(0, 80) : null,
      type: el.getAttribute('type'),
      name: el.getAttribute('name'),
      value: el.getAttribute('value'),
      text: (el.innerText || el.value || '').trim().slice(0, 30) || null,
    });
  }
  return out;
}
"""


def scan(page, label: str) -> list[dict]:
    items = page.evaluate(_VISIBLE_SCAN)
    print(f"\n===== {label} : {len(items)}개 =====")
    for item in items:
        if item["id"] or item["type"] in ("radio", "checkbox", "file"):
            print(
                f"  {item['tag']:8} id={str(item['id'])[:34]:36} "
                f"type={str(item['type'])[:8]:10} text={str(item['text'])[:26]}"
            )
    return items


def main() -> int:
    config = load_config()
    blog_url = config["blog_url"].rstrip("/")
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    report: dict[str, list[dict]] = {}

    with open_context(headless=True) as context:
        page = context.pages[0] if context.pages else context.new_page()
        page.on("dialog", lambda dialog: dialog.dismiss())
        page.goto(f"{blog_url}/manage/newpost/", wait_until="domcontentloaded")
        if "/auth/login" in page.url:
            print("[실패] 로그인이 필요합니다.")
            return 1
        page.wait_for_timeout(6000)

        report["baseline"] = scan(page, "기본 화면")

        # 1) 본문 iframe 구조
        try:
            body_html = page.frame_locator("#editor-tistory_ifr").locator("body").inner_html()
            print("\n===== 본문 iframe body =====")
            print(" ", body_html[:200].replace("\n", " "))
            report["iframe_body"] = [{"html": body_html[:2000]}]
        except Exception as error:
            print(f"\n[경고] 본문 iframe 접근 실패: {error}")

        # 2) 에디터 모드 드롭다운
        try:
            page.click("#editor-mode-layer-btn-open")
            page.wait_for_timeout(800)
            report["mode_menu"] = scan(page, "에디터 모드 드롭다운")
            page.keyboard.press("Escape")
            page.wait_for_timeout(500)
        except Exception as error:
            print(f"[경고] 모드 드롭다운 실패: {error}")

        # 3) 첨부 레이어
        try:
            page.click("#attach-layer-btn")
            page.wait_for_timeout(800)
            report["attach_menu"] = scan(page, "첨부 레이어")
            page.keyboard.press("Escape")
            page.wait_for_timeout(500)
        except Exception as error:
            print(f"[경고] 첨부 레이어 실패: {error}")

        # 4) file input 목록 (숨김 포함)
        inputs = page.evaluate(
            """() => Array.from(document.querySelectorAll("input[type=file]"))
                 .map(el => ({ id: el.id||null, accept: el.accept||null,
                               multiple: el.multiple, cls: el.className||null }))"""
        )
        print(f"\n===== file input {len(inputs)}개 =====")
        for item in inputs:
            print(f"  {item}")
        report["file_inputs"] = inputs

        # 5) 발행 레이어 (열기만 — 절대 발행 안 함)
        try:
            page.click("#publish-layer-btn")
            page.wait_for_timeout(1500)
            report["publish_layer"] = scan(page, "발행 레이어")
            page.screenshot(path=str(DEBUG_DIR / "publish-layer.png"), full_page=True)
        except Exception as error:
            print(f"[경고] 발행 레이어 실패: {error}")

        (DEBUG_DIR / "menus.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    print(f"\n[완료] {DEBUG_DIR / 'menus.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
