"""최초 1회 카카오 로그인 (사람이 직접 로그인).

    python src/login.py

브라우저 창이 뜨면 카카오 계정으로 로그인만 하면 된다.
로그인이 감지되면 세션이 .auth/ 에 저장되고 창이 닫힌다.
이후 발행 스크립트는 이 세션을 재사용하므로 다시 로그인할 필요가 없다.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import (  # noqa: E402
    AUTH_DIR,
    STATE_PATH,
    load_config,
    open_context,
    save_state,
)

WAIT_LIMIT_SECONDS = 600
POLL_INTERVAL_SECONDS = 2
FORCED_CHECK_SECONDS = 15  # 쿠키 신호와 무관하게 관리 페이지를 직접 찔러보는 주기


def main() -> int:
    config = load_config()
    blog_url = config["blog_url"].rstrip("/")

    print("=" * 60)
    print("티스토리 로그인 (최초 1회)")
    print("=" * 60)
    print("브라우저 창이 열립니다. 카카오 계정으로 로그인해주세요.")
    print(f"제한 시간: {WAIT_LIMIT_SECONDS}초\n")

    # 로그인은 반드시 사람이 직접 해야 하므로 창을 띄운다.
    with open_context(headless=False) as context:
        page = context.pages[0] if context.pages else context.new_page()
        try:
            page.goto(f"{blog_url}/manage", wait_until="domcontentloaded")
        except Exception as error:
            print(f"[실패] 페이지를 열지 못했습니다: {error}")
            return 1

        if "/auth/login" not in page.url:
            print("[완료] 이미 로그인되어 있습니다.")
            save_state(context)
            _report_profile()
            return 0

        # URL 폴링은 카카오 로그인이 팝업/새 탭으로 뜨면 놓친다.
        # 탭 위치와 무관한 컨텍스트 쿠키를 본다.
        deadline = time.time() + WAIT_LIMIT_SECONDS
        next_forced_check = time.time() + FORCED_CHECK_SECONDS

        while time.time() < deadline:
            time.sleep(POLL_INTERVAL_SECONDS)

            try:
                cookies = context.cookies()
            except Exception:
                print("[실패] 브라우저 창이 닫혔습니다. 다시 실행해주세요.")
                return 1

            # 쿠키 이름이 바뀌어도 놓치지 않도록 주기적으로 강제 확인한다.
            forced = time.time() >= next_forced_check
            if forced:
                next_forced_check = time.time() + FORCED_CHECK_SECONDS
            if not forced and not _has_tistory_session(cookies):
                continue

            # 쿠키가 보이면 실제로 관리 페이지가 열리는지 확인한다.
            checker = context.new_page()
            try:
                checker.goto(f"{blog_url}/manage", wait_until="domcontentloaded")
                landed = checker.url
            except Exception:
                continue
            finally:
                try:
                    checker.close()
                except Exception:
                    pass

            if "/auth/login" not in landed:
                save_state(context)
                if not _verify_state_usable():
                    print("\n[실패] 로그인은 됐지만 세션 저장이 확인되지 않았습니다.")
                    print("  → 로그인 화면의 '로그인 상태 유지'를 체크하고 다시 시도해주세요.")
                    return 1
                print("\n[완료] 로그인 성공! 세션을 저장했습니다.")
                _report_profile()
                return 0

        print("\n[실패] 제한 시간 안에 로그인이 완료되지 않았습니다.")
        return 1


# 비로그인 상태에서도 깔리는 쿠키(_T_ANO, TSID, UUID 등)는 신호가 아니다.
# 실측 확인: 로그인 전 티스토리 쿠키는 REACTION_GUEST/TSID/TUID/UUID/_T_ANO/__T_ 등.
_SESSION_COOKIE_NAMES = ("TSSESSION", "TISTORY_AUTH")


def _has_tistory_session(cookies: list[dict]) -> bool:
    """티스토리 로그인 쿠키가 심어졌는지 본다 (빠른 감지용 힌트).

    이름이 바뀌어도 FORCED_CHECK_SECONDS 주기의 직접 확인이 받쳐주므로
    여기서 놓쳐도 로그인 감지 자체는 실패하지 않는다.
    """
    for cookie in cookies:
        if "tistory.com" not in cookie.get("domain", ""):
            continue
        if cookie.get("name") in _SESSION_COOKIE_NAMES:
            return True
    return False


def _verify_state_usable() -> bool:
    """백업 파일에 티스토리 인증 쿠키가 실제로 담겼는지 확인한다.

    '성공했다'고 말해놓고 다음 실행에서 로그인이 풀려 있는 사태를 막는다.
    """
    if not STATE_PATH.is_file():
        return False
    try:
        with STATE_PATH.open(encoding="utf-8") as fp:
            cookies = json.load(fp).get("cookies") or []
    except (json.JSONDecodeError, OSError):
        return False

    # 비로그인 상태에서도 깔리는 쿠키를 빼고 남는 게 있어야 한다.
    anonymous = {"REACTION_GUEST", "TSID", "TUID", "UUID", "_T_ANO", "TOP-XSRF-TOKEN"}
    meaningful = [
        cookie["name"]
        for cookie in cookies
        if "tistory.com" in cookie.get("domain", "") and cookie["name"] not in anonymous
    ]
    return len(meaningful) > 0


def _report_profile() -> None:
    print(f"세션 위치: {AUTH_DIR}")
    print("이제 python src/publish.py posts/<원고>.json 으로 자동 발행할 수 있습니다.")


if __name__ == "__main__":
    raise SystemExit(main())
