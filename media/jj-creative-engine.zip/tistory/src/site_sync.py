"""티스토리에 발행된 글을 홈페이지(jj-aiedu)에 반영하고 배포한다.

    python src/site_sync.py            # 데이터 생성 + 커밋 + 푸시(자동 배포)
    python src/site_sync.py --dry-run  # 파일만 만들고 푸시는 하지 않음

하는 일:
  1) 티스토리 RSS에서 발행된 글의 실제 URL을 얻는다
  2) state.json / 원고 JSON / 네이버 원문에서 날짜·요약·태그를 모은다
  3) 썸네일을 홈페이지 public/training/ 으로 복사한다
  4) src/data/trainingLog.ts 를 생성한다
  5) git commit + push → Vercel이 자동 배포한다

⚠️ 홈페이지의 courses[] 배열은 '모집 중인 유료 공개과정'이다. 교육 후기를 거기에 넣으면
   가격·신청 버튼이 붙어 모집 과정처럼 보이므로 절대 넣지 않는다.
   후기는 별도 데이터(trainingLog)로 분리해 캘린더의 'delivery' 타입과
   COURSES 페이지의 '교육 진행 사례' 섹션에서만 쓴다.
"""

from __future__ import annotations

import argparse
import html as html_lib
import json
import re
import subprocess
import sys
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src import sync_state  # noqa: E402

SITE_ROOT = PROJECT_ROOT.parent / "jj-aiedu"
DATA_FILE = SITE_ROOT / "src/data/trainingLog.ts"
PUBLIC_DIR = SITE_ROOT / "public/training"
TISTORY_RSS = "https://YOUR_TISTORY_ID.tistory.com/rss"
BLOG_BASE = "https://YOUR_TISTORY_ID.tistory.com"
MAX_POST_SCAN = 300          # 번호 훑기 상한
CONSECUTIVE_MISS_LIMIT = 15  # 연속 빈 번호가 이만큼이면 끝으로 본다
URL_CACHE = PROJECT_ROOT / "work" / "url-cache.json"

_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}


def fetch(url: str) -> str:
    request = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read().decode("utf-8", errors="ignore")


def normalize(text: str) -> str:
    """RSS 제목은 이중 이스케이프되어 있어 비교 전에 펴 준다."""
    plain = html_lib.unescape(html_lib.unescape(text))
    return re.sub(r"[^0-9a-zA-Z가-힣]", "", plain)


def tistory_urls() -> list[tuple[str, str]]:
    """티스토리 글의 (정규화 제목, URL) 목록을 만든다.

    RSS는 **최신 10건만** 돌려주므로(실측) 사이트맵으로 전체 URL을 훑고,
    RSS에 없는 글은 페이지에서 <title>을 읽어 채운다.
    한 번 확인한 매핑은 url-cache.json에 저장해 다음 실행부터 재조회하지 않는다.
    """
    found: list[tuple[str, str]] = []
    seen_urls: set[str] = set()

    # 1) RSS — 최신 글은 여기서 바로 잡힌다
    try:
        raw = fetch(TISTORY_RSS)
        for item in re.findall(r"<item>(.*?)</item>", raw, re.S):
            title = re.search(r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", item, re.S)
            link = re.search(r"<link>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</link>", item, re.S)
            if title and link:
                url = link.group(1).strip()
                found.append((normalize(title.group(1)), url))
                seen_urls.add(url)
    except Exception as error:
        print(f"  [경고] RSS를 읽지 못했습니다: {error}")

    # 2) 번호 훑기 — 티스토리 글 주소는 /1, /2 … 순번이다.
    #    사이트맵은 방금 올린 글을 늦게 반영하므로(실측) 번호를 직접 확인한다.
    #    404는 삭제된 번호이니 그냥 건너뛴다. 결과는 캐시해 다음 실행에서 재조회하지 않는다.
    cache = _load_cache()
    changed = False
    misses = 0

    for number in range(1, MAX_POST_SCAN + 1):
        url = f"{BLOG_BASE}/{number}"
        if url in seen_urls:
            misses = 0
            continue

        title = cache.get(url)
        if title is None:
            try:
                page = fetch(url)
                match = re.search(r"<title>(.*?)</title>", page, re.S)
                title = match.group(1).strip() if match else ""
            except Exception:
                title = ""          # 404 등 — 없는 번호
            cache[url] = title
            changed = True

        if title:
            found.append((normalize(title), url))
            misses = 0
        else:
            misses += 1
            if misses >= CONSECUTIVE_MISS_LIMIT:
                break               # 연속으로 비면 끝에 도달한 것

    if changed:
        _save_cache(cache)
    return found


def _load_cache() -> dict:
    if not URL_CACHE.is_file():
        return {}
    try:
        return json.loads(URL_CACHE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save_cache(cache: dict) -> None:
    URL_CACHE.write_text(json.dumps(cache, ensure_ascii=False, indent=1), encoding="utf-8")


def find_manuscript(log_no: str) -> dict | None:
    # 🔴 posts/ 를 그냥 rglob 하면 instagram/·threads/ 원고가 먼저 걸린다 (2026-08-03).
    # 그 둘은 caption/text 만 있고 blocks·tags 가 없어서 요약과 태그가 통째로 빈다.
    # 본문 원고는 published/ 에만 있으므로 거기부터 찾는다.
    posts = PROJECT_ROOT / "posts"
    candidates = list((posts / "published").glob(f"*{log_no}*.json"))
    candidates += [p for p in posts.rglob(f"*{log_no}*.json") if p not in candidates]

    for path in candidates:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
    return None


def naver_date(log_no: str) -> str:
    source = PROJECT_ROOT / "work" / log_no / "source.json"
    if not source.is_file():
        return ""
    try:
        return json.loads(source.read_text(encoding="utf-8")).get("published", "")
    except (json.JSONDecodeError, OSError):
        return ""


def first_paragraph(manuscript: dict) -> str:
    for block in manuscript.get("blocks", []):
        if block.get("type") == "p":
            return block.get("text", "").split("\n")[0]
    return ""


def build_records() -> list[dict]:
    published = sync_state.load()["published"]
    url_map = tistory_urls()
    records = []

    for log_no, entry in published.items():
        manuscript = find_manuscript(log_no)
        if manuscript is None:
            print(f"  [건너뜀] {log_no}: 원고 JSON을 찾지 못했습니다.")
            continue

        wanted = normalize(entry["title"])
        url = next((link for title, link in url_map if title == wanted), "")
        if not url:
            # 제목 앞부분만으로 한 번 더 시도한다 (RSS가 제목을 자를 때가 있다)
            url = next((link for title, link in url_map if title.startswith(wanted[:20])), "")
        if not url:
            print(f"  [건너뜀] {log_no}: 티스토리에서 URL을 찾지 못했습니다 (비공개 글이면 정상 — 공개 전환 후 반영됨).")
            continue

        date = naver_date(log_no)
        if not date:
            print(f"  [건너뜀] {log_no}: 날짜를 찾지 못했습니다.")
            continue

        thumb_source = PROJECT_ROOT / "thumbs" / f"{log_no}.png"
        thumbnail = ""
        if thumb_source.is_file():
            PUBLIC_DIR.mkdir(parents=True, exist_ok=True)
            (PUBLIC_DIR / f"{log_no}.png").write_bytes(thumb_source.read_bytes())
            thumbnail = f"/training/{log_no}.png"

        records.append(
            {
                "id": log_no,
                "title": html_lib.unescape(entry["title"]),
                "date": date,
                "summary": first_paragraph(manuscript),
                "thumbnail": thumbnail,
                "tags": manuscript.get("tags", [])[:4],
                "url": url,
            }
        )

    records.sort(key=lambda record: record["date"], reverse=True)
    return records


def render_ts(records: list[dict]) -> str:
    body = ",\n".join(
        "  {\n"
        + ",\n".join(
            f"    {key}: {json.dumps(value, ensure_ascii=False)}"
            for key, value in record.items()
        )
        + "\n  }"
        for record in records
    )
    return (
        "// 이 파일은 자동 생성됩니다. 직접 수정하지 마세요.\n"
        "// 생성: tistory 프로젝트의 `python src/site_sync.py`\n"
        "// 티스토리에 발행된 기업교육 후기 기록입니다.\n"
        "// 모집 중인 유료 공개과정(courses 배열)과는 성격이 다르므로 섞지 마세요.\n\n"
        "export type TrainingRecord = {\n"
        "  id: string;\n"
        "  title: string;\n"
        "  date: string;      // YYYY-MM-DD\n"
        "  summary: string;\n"
        "  thumbnail: string; // public/ 기준 경로 (없으면 빈 문자열)\n"
        "  tags: string[];\n"
        "  url: string;       // 티스토리 원문\n"
        "};\n\n"
        f"export const trainingLog: TrainingRecord[] = [\n{body}\n];\n"
    )


def git(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args], cwd=SITE_ROOT, capture_output=True, text=True
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="홈페이지 동기화 + 배포")
    parser.add_argument("--dry-run", action="store_true", help="파일만 만들고 푸시하지 않음")
    args = parser.parse_args()

    if not SITE_ROOT.is_dir():
        print(f"[실패] 홈페이지 저장소가 없습니다: {SITE_ROOT}")
        print("  → gh repo clone YOUR_GITHUB_ID/YOUR_SITE_REPO 로 먼저 받아주세요.")
        return 1

    print("티스토리 발행 글 수집...")
    records = build_records()
    if not records:
        print("[중단] 반영할 글이 없습니다.")
        return 0

    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    DATA_FILE.write_text(render_ts(records), encoding="utf-8")
    print(f"[생성] {DATA_FILE} ({len(records)}건)")
    for record in records:
        print(f"  {record['date']}  {record['title'][:44]}  → {record['url']}")

    if args.dry_run:
        print("\n[--dry-run] 커밋/푸시를 건너뜁니다.")
        return 0

    status = git("status", "--porcelain")
    if not status.stdout.strip():
        print("\n변경 사항이 없어 배포하지 않습니다.")
        return 0

    # 무인 실행이므로 이 스크립트가 만들어내는 산출물만 커밋한다.
    # (git add -A 는 무관한 파일까지 올릴 수 있어 쓰지 않는다)
    owned = ("src/data/trainingLog.ts", "public/training", "public/cards")
    git("add", *owned)

    # 손으로 고친 컴포넌트 등이 남아 있으면 알려만 준다 (자동 커밋하지 않는다).
    leftovers = []
    for line in status.stdout.strip().splitlines():
        path = line[2:].strip().split(" -> ")[-1].strip('"')
        if not any(path.startswith(prefix) for prefix in owned):
            leftovers.append(path)
    if leftovers:
        print("  [알림] 아래 변경은 커밋하지 않았습니다. 필요하면 직접 커밋하세요:")
        for path in leftovers[:10]:
            print(f"    - {path}")
    commit = git("commit", "-m", f"chore: 교육 진행 사례 {len(records)}건 동기화")
    if commit.returncode != 0 and "nothing to commit" not in commit.stdout:
        print(f"[실패] 커밋 실패: {commit.stdout or commit.stderr}")
        return 1

    # 원격에 다른 커밋이 있으면 푸시가 거부되므로 먼저 맞춘다.
    pull = git("pull", "--rebase")
    if pull.returncode != 0:
        print(f"[실패] 원격 반영 실패(rebase): {pull.stderr[:300]}")
        git("rebase", "--abort")
        return 1

    push = git("push")
    if push.returncode != 0:
        print(f"[실패] 푸시 실패: {push.stderr[:300]}")
        return 1

    print("\n[완료] 푸시됨 → Vercel이 자동 배포합니다 (1~2분)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
