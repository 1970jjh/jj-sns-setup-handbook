"""API 시크릿을 config.json에 안전하게 넣는다.

    python src/set_secret.py threads
    python src/set_secret.py instagram

입력한 값은 화면에 표시되지 않고, 로그에도 남지 않는다.
확인용으로 끝 4자리만 보여준다.
"""

from __future__ import annotations

import getpass
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = PROJECT_ROOT / "config.json"
TARGETS = ("threads", "instagram", "gemini", "youtube")


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in TARGETS:
        print(f"사용법: python src/set_secret.py [{' | '.join(TARGETS)}]")
        return 1
    target = sys.argv[1]

    try:
        config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as error:
        print(f"[실패] config.json을 읽지 못했습니다: {error}")
        return 1

    print(f"{target} 앱 시크릿을 붙여넣고 Enter를 누르세요.")
    print("(입력 내용은 화면에 표시되지 않습니다)")
    secret = getpass.getpass("시크릿: ").strip()

    if not secret:
        print("[중단] 입력이 비어 있습니다.")
        return 1
    if len(secret) < 16:
        print(f"[중단] 너무 짧습니다({len(secret)}자). 잘못 붙여넣은 것 같습니다.")
        return 1

    # gemini는 API 키라 app_secret이 아니라 api_key로 둔다.
    field = "api_key" if target in ("gemini",) else "app_secret"
    config.setdefault(target, {})[field] = secret
    CONFIG_PATH.write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"[완료] 저장했습니다 (길이 {len(secret)}, 끝 4자리 ...{secret[-4:]})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
