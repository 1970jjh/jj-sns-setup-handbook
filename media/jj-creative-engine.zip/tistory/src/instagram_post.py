"""인스타그램 캐러셀(카드뉴스) 발행.

    python src/instagram_post.py posts/instagram/<logNo>.json
    python src/instagram_post.py posts/instagram/<logNo>.json --dry-run

원고 JSON:
{
  "source_log_no": "224341335671",
  "caption": "본문 (2200자 이내, 해시태그 포함)",
  "images": [
    "https://jj-aiedu.vercel.app/cards/224341335671/01.jpg",
    ...
  ]
}

캐러셀은 3단계로 올린다:
  1) 각 이미지를 '자식 컨테이너'로 만든다 (is_carousel_item=true)
  2) 자식들을 묶어 캐러셀 컨테이너를 만든다 (media_type=CAROUSEL)
  3) 발행한다

이미지는 **외부에서 접근 가능한 공개 JPEG URL**이어야 한다.
홈페이지(jj-aiedu)에 올려 배포한 뒤 그 주소를 쓴다.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src import sync_state  # noqa: E402

API_BASE = "https://graph.instagram.com/v21.0"
TOKEN_PATH = PROJECT_ROOT / ".auth" / "instagram.json"

CAPTION_LIMIT = 2200      # 인스타 캡션 상한
MIN_CARDS = 2             # 캐러셀 최소 장수
MAX_CARDS = 10            # 캐러셀 최대 장수
CHILD_WAIT_SECONDS = 3    # 자식 컨테이너 처리 대기
PUBLISH_WAIT_SECONDS = 6  # 캐러셀 컨테이너 처리 대기


class InstagramError(RuntimeError):
    """인스타 발행 실패."""


def load_token() -> dict:
    if not TOKEN_PATH.is_file():
        raise InstagramError(
            "인스타 토큰이 없습니다.\n"
            "  → python src/set_token.py instagram 으로 토큰을 저장해주세요."
        )
    try:
        return json.loads(TOKEN_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as error:
        raise InstagramError(f"토큰 파일을 읽지 못했습니다: {error}") from None


def _post(path: str, params: dict) -> dict:
    body = urllib.parse.urlencode(params).encode()
    request = urllib.request.Request(f"{API_BASE}/{path}", data=body, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as error:
        detail = error.read().decode(errors="ignore")[:400]
        raise InstagramError(f"HTTP {error.code}: {detail}") from None


def _get(path: str, params: dict) -> dict:
    query = urllib.parse.urlencode(params)
    request = urllib.request.Request(f"{API_BASE}/{path}?{query}", method="GET")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as error:
        detail = error.read().decode(errors="ignore")[:400]
        raise InstagramError(f"HTTP {error.code}: {detail}") from None


def permalink(media_id: str, access_token: str) -> str:
    """게시물의 공개 주소를 조회한다.

    🔴 `https://www.instagram.com/p/<media_id>/` 로 조립하면 안 된다 (2026-07-31 실측).
    `/p/` 뒤에 오는 것은 짧은 shortcode이고 media_id는 별개의 숫자 ID라
    그렇게 만든 주소는 **'페이지를 사용할 수 없습니다'** 가 뜬다.
    반드시 Graph API의 permalink 필드를 조회해야 한다.
    """
    data = _get(media_id, {"fields": "permalink", "access_token": access_token})
    link = data.get("permalink")
    if not link:
        raise InstagramError(f"permalink를 받지 못했습니다: {data}")
    return link


def validate(manuscript: dict) -> tuple[str, list[str]]:
    caption = (manuscript.get("caption") or "").strip()
    images = manuscript.get("images") or []

    if not caption:
        raise InstagramError("caption이 비어 있습니다.")
    if len(caption) > CAPTION_LIMIT:
        raise InstagramError(
            f"캡션이 {len(caption)}자입니다. 인스타는 {CAPTION_LIMIT}자까지만 됩니다."
        )
    if not MIN_CARDS <= len(images) <= MAX_CARDS:
        raise InstagramError(
            f"이미지가 {len(images)}장입니다. 캐러셀은 {MIN_CARDS}~{MAX_CARDS}장이어야 합니다."
        )
    for url in images:
        if not url.startswith("https://"):
            raise InstagramError(f"이미지는 https 공개 주소여야 합니다: {url}")
    return caption, images


def check_reachable(images: list[str]) -> None:
    """인스타 서버가 이미지를 못 받으면 원인 없이 실패하므로 먼저 확인한다."""
    for url in images:
        request = urllib.request.Request(url, method="HEAD")
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                if response.status != 200:
                    raise InstagramError(f"이미지에 접근할 수 없습니다({response.status}): {url}")
        except urllib.error.HTTPError as error:
            raise InstagramError(f"이미지에 접근할 수 없습니다({error.code}): {url}") from None
        except InstagramError:
            raise
        except Exception as error:
            raise InstagramError(f"이미지 확인 실패: {url} ({error})") from None


def publish(manuscript: dict, dry_run: bool = False) -> str:
    caption, images = validate(manuscript)

    print(f"캡션 {len(caption)}자 / 카드 {len(images)}장")
    print("-" * 60)
    print(caption[:400] + ("..." if len(caption) > 400 else ""))
    print("-" * 60)
    for order, url in enumerate(images, 1):
        print(f"  {order:2}. {url}")

    if dry_run:
        print("\n[--dry-run] 실제로 올리지 않았습니다.")
        return "(미발행)"

    check_reachable(images)

    token = load_token()
    user_id = token["user_id"]
    access_token = token["access_token"]

    # 1) 자식 컨테이너
    children = []
    for order, url in enumerate(images, 1):
        child = _post(
            f"{user_id}/media",
            {
                "image_url": url,
                "is_carousel_item": "true",
                "access_token": access_token,
            },
        )
        child_id = child.get("id")
        if not child_id:
            raise InstagramError(f"{order}번째 카드 컨테이너 생성 실패: {child}")
        children.append(child_id)
        print(f"    카드 {order}/{len(images)} 준비 완료")
        time.sleep(CHILD_WAIT_SECONDS)

    # 2) 캐러셀 컨테이너
    carousel = _post(
        f"{user_id}/media",
        {
            "media_type": "CAROUSEL",
            "children": ",".join(children),
            "caption": caption,
            "access_token": access_token,
        },
    )
    creation_id = carousel.get("id")
    if not creation_id:
        raise InstagramError(f"캐러셀 컨테이너 생성 실패: {carousel}")
    print(f"  캐러셀 컨테이너: {creation_id}")
    time.sleep(PUBLISH_WAIT_SECONDS)

    # 3) 발행
    published = _post(
        f"{user_id}/media_publish",
        {"creation_id": creation_id, "access_token": access_token},
    )
    media_id = published.get("id")
    if not media_id:
        raise InstagramError(f"발행 실패: {published}")

    url = permalink(media_id, access_token)

    log_no = manuscript.get("source_log_no")
    if log_no:
        sync_state.mark_shared(str(log_no), url, channel="instagram")
        print(f"  인스타 이력 기록: naver {log_no}")

    return url


def main() -> int:
    parser = argparse.ArgumentParser(description="인스타그램 캐러셀 발행")
    parser.add_argument("manuscript", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    try:
        data = json.loads(args.manuscript.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as error:
        print(f"[실패] 원고를 읽지 못했습니다: {error}")
        return 1

    try:
        url = publish(data, args.dry_run)
    except InstagramError as error:
        print(f"\n[실패] {error}")
        return 1

    print(f"\n[완료] {url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
