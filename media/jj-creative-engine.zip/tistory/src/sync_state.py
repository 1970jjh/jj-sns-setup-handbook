"""티스토리에 이미 발행한 네이버 글을 기록한다.

노트북이 며칠 꺼져 있어도 누락이 생기지 않도록, '전날 글'이 아니라
'아직 발행 안 된 글 전부'를 기준으로 동기화하기 위한 상태 파일이다.

state.json 형식:
{
  "published": {                     # 티스토리 발행 이력
    "<naver logNo>": {"title": "...", "url": "...", "at": "2026-07-30T10:12:00+09:00"}
  },
  "threads": {                       # 스레드 발행 이력
    "<naver logNo>": {"url": "...", "at": "..."}
  }
}

플랫폼별로 이력을 따로 두는 이유: 티스토리는 올라갔는데 스레드가 실패한 경우
스레드만 다시 시도해야 하기 때문이다.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
STATE_PATH = PROJECT_ROOT / "state.json"
KST = timezone(timedelta(hours=9))


def load() -> dict:
    if not STATE_PATH.is_file():
        return {"published": {}}
    try:
        with STATE_PATH.open(encoding="utf-8") as fp:
            data = json.load(fp)
    except (json.JSONDecodeError, OSError) as error:
        print(f"  [경고] state.json을 읽지 못했습니다({error}). 빈 상태로 시작합니다.")
        return {"published": {}}
    if not isinstance(data.get("published"), dict):
        return {"published": {}}
    return data


def is_published(log_no: str) -> bool:
    return str(log_no) in load()["published"]


def mark_published(log_no: str, title: str, url: str) -> None:
    """발행 성공을 기록한다. 실패한 글은 기록하지 않아 다음 실행 때 다시 시도된다."""
    state = load()
    state["published"][str(log_no)] = {
        "title": title,
        "url": url,
        "at": datetime.now(KST).isoformat(timespec="seconds"),
    }
    STATE_PATH.write_text(
        json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8"
    )


def pending(posts: list[dict]) -> list[dict]:
    """네이버 글 목록에서 아직 티스토리에 안 올라간 것만 오래된 순으로 돌려준다."""
    done = load()["published"]
    remaining = [post for post in posts if str(post["log_no"]) not in done]
    return sorted(remaining, key=lambda post: post.get("published", ""))


def summary() -> str:
    state = load()
    return f"발행 완료 {len(state['published'])}건 (기록: {STATE_PATH})"


# ---------------------------------------------------------------- 스레드


def _channel(state: dict, name: str) -> dict:
    """플랫폼별 이력 칸을 꺼낸다 (없으면 만든다)."""
    if not isinstance(state.get(name), dict):
        state[name] = {}
    return state[name]


def is_shared(log_no: str, channel: str = "threads") -> bool:
    return str(log_no) in _channel(load(), channel)


def mark_shared(log_no: str, url: str, channel: str = "threads") -> None:
    """다른 채널(스레드/인스타) 발행 성공을 기록한다."""
    state = load()
    _channel(state, channel)[str(log_no)] = {
        "url": url,
        "at": datetime.now(KST).isoformat(timespec="seconds"),
    }
    STATE_PATH.write_text(
        json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8"
    )


def pending_share(channel: str = "threads", limit: int = 0) -> list[dict]:
    """티스토리에는 올라갔지만 해당 채널에는 아직 안 올라간 글 목록.

    오래된 순으로 돌려준다. 티스토리 발행이 선행 조건이므로 published 기준으로 찾는다.
    """
    state = load()
    done = _channel(state, channel)
    remaining = [
        {"log_no": log_no, **entry}
        for log_no, entry in state["published"].items()
        if log_no not in done
    ]
    remaining.sort(key=lambda item: item.get("at", ""))
    return remaining[:limit] if limit else remaining
