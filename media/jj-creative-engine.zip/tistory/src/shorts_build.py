"""유튜브 쇼츠를 한 번에 만든다 — 검증 → TTS → 길이보정 → TTS → 무음검증 → 렌더 → 업로드.

    python src/shorts_build.py <슬러그> --log-no <네이버 logNo>
    python src/shorts_build.py <슬러그> --no-upload      # 렌더까지만

전제: `C:/Users/YOUR_NAME/유투브/public/<슬러그>/` 에 `script.json` 과
`scene_01.png ...` 가 준비돼 있어야 한다. 실제 렌더·TTS·업로드는 그 프로젝트의
스크립트(Gemini TTS + Remotion)를 그대로 호출한다. 여기서 하는 일은 **순서 고정과 검증**이다.

🔴 왜 한 스크립트로 묶었나
이 파이프라인은 순서를 틀리면 **조용히 나쁜 결과**가 나온다. 2026-07-30~31에 네 번 헛돌았다:
  · 씬 길이를 미리 고정 → 54초 영상에 무음 19.5초(36%)
  · subtitles.json으로 발화 길이를 측정 → 수렴하지 않고 54→74→63초로 진동
  · TTS가 3/8만 끝났는데 다음 단계로 진행
  · 업로더의 하드코딩된 썸네일 경로 때문에 **한 달 전 다른 영상의 썸네일**이 붙은 채 공개됨
문서로만 적어두면 또 어긋나므로 코드로 고정한다. 검증에 걸리면 렌더까지 가지 않고 멈춘다.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src import sync_state  # noqa: E402

VIDEO_ROOT = Path("C:/Users/YOUR_NAME/유투브")
PUBLIC_ROOT = VIDEO_ROOT / "public"

MAX_DURATION = 60.0   # 쇼츠 상한
MAX_GAP = 2.0         # 허용 무음 상한 (사용자 확정)
MIN_SCENES, MAX_SCENES = 8, 10
MIN_PHOTOS = 3        # 원문 실사 사진 최소 장수


class BuildError(RuntimeError):
    """중단해야 하는 검증 실패."""


def run(command: list[str], *, cwd: Path, label: str, env: dict | None = None) -> None:
    print(f"\n▶ {label}")
    merged = {**os.environ, **(env or {})}
    result = subprocess.run(command, cwd=str(cwd), env=merged, shell=False)
    if result.returncode != 0:
        raise BuildError(f"{label} 실패 (exit={result.returncode})")


def validate_script(project: Path) -> dict:
    """렌더 전에 잡을 수 있는 문제를 전부 잡는다 (렌더는 몇 분 걸린다)."""
    script_path = project / "script.json"
    if not script_path.is_file():
        raise BuildError(f"script.json이 없습니다: {script_path}")

    script = json.loads(script_path.read_text(encoding="utf-8"))
    scenes = script.get("scenes", [])
    problems: list[str] = []

    if not MIN_SCENES <= len(scenes) <= MAX_SCENES:
        problems.append(f"씬 수 {len(scenes)}개 (기준 {MIN_SCENES}~{MAX_SCENES}장)")

    title = script.get("title", "")
    if not title:
        problems.append("title이 비어 있습니다")
    elif "JJ Creative 교육연구소" in title:
        problems.append("title에 'JJ Creative 교육연구소'가 있습니다 — 업로더가 자동으로 붙여 중복됩니다")
    if not script.get("description"):
        problems.append("description이 비어 있습니다 (유튜브 설명란에 그대로 들어갑니다)")
    if not script.get("tags"):
        problems.append("tags가 비어 있습니다")

    for index, scene in enumerate(scenes, 1):
        scene_id = scene.get("id", "")
        if not re.fullmatch(r"scene_\d{2}", scene_id):
            problems.append(f"[{index}] id '{scene_id}' — 'scene_01' 형식이어야 렌더러가 이미지를 찾습니다")
            continue
        if not (project / f"{scene_id}.png").is_file():
            problems.append(f"[{index}] {scene_id}.png 파일이 없습니다")
        narration = scene.get("narration", "").strip()
        if not narration:
            problems.append(f"[{index}] narration이 비어 있습니다")
        elif len(re.findall(r"[.!?]", narration)) < 2:
            problems.append(f"[{index}] narration이 한 문장입니다 — 두 문장 이상이어야 무음이 안 생깁니다")

    # 씬에 source를 적어두면 실사/생성 비율까지 검증한다
    sources = [scene.get("source") for scene in scenes]
    if all(sources):
        photos = sources.count("photo")
        generated = len(scenes) - photos
        if photos < MIN_PHOTOS:
            problems.append(f"실사 사진 {photos}장 (기준 {MIN_PHOTOS}장 이상)")
        if abs(photos - generated) > 1:
            problems.append(f"실사:생성 = {photos}:{generated} — 5:5에 맞추세요")
    else:
        print('  (참고) 씬에 "source": "photo"|"generated"를 넣으면 5:5 비율까지 검증합니다')

    if problems:
        raise BuildError("script.json 검증 실패\n  - " + "\n  - ".join(problems))

    print(f"  검증 통과 — 씬 {len(scenes)}개 / 제목 「{title[:40]}」")
    return script


def silence_gaps(audio: Path, threshold: float) -> list[float]:
    """threshold 초를 넘는 무음 구간의 길이 목록."""
    result = subprocess.run(
        ["ffmpeg", "-i", str(audio), "-af",
         f"silencedetect=noise=-35dB:d={threshold}", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    return [float(v) for v in re.findall(r"silence_duration: ([0-9.]+)", result.stderr)]


def audio_duration(audio: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(audio)],
        capture_output=True, text=True,
    )
    return float(result.stdout.strip() or 0)


def generate_tts(project: Path, label: str) -> None:
    run([sys.executable, "scripts/generate_tts.py"], cwd=VIDEO_ROOT, label=label,
        env={"TTS_ENGINE": "gemini", "OUTPUT_DIR": str(project)})


def stage_to_public_root(project: Path) -> None:
    """렌더러는 public 루트만 본다. 슬러그 폴더 내용을 그대로 올린다."""
    for name in ("script.json", "narration_full.mp3", "subtitles.json"):
        source = project / name
        if source.is_file():
            shutil.copy2(source, PUBLIC_ROOT / name)
    for image in project.glob("scene_*.png"):
        shutil.copy2(image, PUBLIC_ROOT / image.name)


def fix_metadata(project: Path, video_id: str, script: dict) -> None:
    """업로드 후 설명·태그·썸네일을 쇼츠에 맞게 바로잡는다.

    upload_youtube.py는 3~5분짜리 교육영상용이라 쇼츠에 안 맞는 두 가지를 한다:
      · 썸네일 경로가 public/scene_01_hook.png 로 하드코딩 — 과거 영상 파일이 붙는다
      · 씬 keywords로 목차를 만들어 설명에 넣는다 — 60초짜리엔 무의미하다
    원본을 고치면 그 스크립트를 쓰는 다른 영상 작업이 깨지므로 여기서 덮어쓴다.
    """
    sys.path.insert(0, str(VIDEO_ROOT / "scripts"))
    from upload_youtube import get_credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload

    youtube = build("youtube", "v3", credentials=get_credentials())
    snippet = youtube.videos().list(part="snippet", id=video_id).execute()["items"][0]["snippet"]
    snippet["description"] = script["description"].strip() + "\n\nJJ Creative 교육연구소"
    snippet["tags"] = (script.get("tags", []) + ["JJ Creative", "교육연구소"])[:15]
    youtube.videos().update(part="snippet", body={"id": video_id, "snippet": snippet}).execute()

    youtube.thumbnails().set(
        videoId=video_id,
        media_body=MediaFileUpload(str(project / "scene_01.png"), mimetype="image/png"),
    ).execute()
    print("  설명·태그·썸네일 보정 완료")


def upload(project: Path, slug: str, script: dict) -> str:
    video = VIDEO_ROOT / "out" / f"{slug}.mp4"
    run([sys.executable, "scripts/upload_youtube.py"], cwd=VIDEO_ROOT,
        label="유튜브 업로드 (전체공개)",
        env={"VIDEO_PATH": str(video), "YT_PRIVACY": "public"})

    report = json.loads((VIDEO_ROOT / "out" / "upload_report.json").read_text(encoding="utf-8"))
    fix_metadata(project, report["video_id"], script)
    # upload_youtube.py는 youtu.be 주소를 돌려주는데 그건 **일반 시청 페이지**라
    # 세로 영상이어도 쇼츠로 보이지 않는다. 쇼츠 주소로 바꿔 기록·보고한다.
    return f"https://www.youtube.com/shorts/{report['video_id']}"


def main() -> int:
    parser = argparse.ArgumentParser(description="유튜브 쇼츠 제작 → 업로드 (순서 고정)")
    parser.add_argument("slug", help="유투브/public/<슬러그>/ 폴더 이름")
    parser.add_argument("--log-no", help="네이버 logNo — 업로드 성공 시 state.json에 기록")
    parser.add_argument("--no-upload", action="store_true", help="렌더까지만 하고 멈춘다")
    args = parser.parse_args()

    project = PUBLIC_ROOT / args.slug
    if not project.is_dir():
        print(f"[실패] 폴더가 없습니다: {project}")
        return 1

    try:
        print(f"[1/6] script.json 검증 — {project}")
        script = validate_script(project)

        generate_tts(project, "[2/6] TTS 1차 생성")

        print("\n[3/6] 씬 길이를 실제 발화에 맞춤")
        run([sys.executable, str(PROJECT_ROOT / "src" / "shorts_fit.py"), str(project)],
            cwd=VIDEO_ROOT, label="길이 보정")

        generate_tts(project, "[4/6] TTS 2차 생성 (보정된 길이로)")

        print("\n[5/6] 무음·길이 검증")
        audio = project / "narration_full.mp3"
        gaps = silence_gaps(audio, MAX_GAP)
        duration = audio_duration(audio)
        print(f"  길이 {duration:.1f}초 / {MAX_GAP}초 초과 무음 {len(gaps)}건")
        if gaps:
            detail = ", ".join(f"{gap:.1f}초" for gap in gaps)
            raise BuildError(
                f"무음 {len(gaps)}건({detail}) — 해당 씬의 narration을 늘리거나 씬을 합치세요")
        if duration > MAX_DURATION:
            raise BuildError(
                f"{duration:.1f}초로 쇼츠 상한 {MAX_DURATION:.0f}초를 넘습니다 — narration을 줄이세요")

        print("\n[6/6] 렌더")
        stage_to_public_root(project)
        run(["npx.cmd", "remotion", "render", "src/index.ts", "ShortsVideo",
             f"out/{args.slug}.mp4", "--timeout=300000"],
            cwd=VIDEO_ROOT, label="Remotion 렌더")

        if args.no_upload:
            print(f"\n[완료] out/{args.slug}.mp4 ({duration:.1f}초) — 업로드는 건너뜀")
            return 0

        url = upload(project, args.slug, script)
        if args.log_no:
            sync_state.mark_shared(args.log_no, url, channel="youtube")
            print(f"  state.json 기록 — logNo {args.log_no}")

        print(f"\n[완료] {url}  ({duration:.1f}초 / 무음 0건)")
        return 0

    except BuildError as error:
        print(f"\n[중단] {error}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
