"""발행 레이어 / 첨부 메뉴만 집중 조사한다 (ID 중복 대응).

티스토리 에디터는 같은 id가 여러 개 존재하는 곳이 있어 :visible로 걸러야 한다.
발행 버튼은 절대 누르지 않는다.

    python src/probe_publish.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import load_config, open_context  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"

_SCAN = """
() => {
  const out = [];
  for (const el of document.querySelectorAll('*')) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const tag = el.tagName.toLowerCase();
    const type = el.getAttribute('type');
    const interactive = ['button','a','input','label','select','textarea'].includes(tag)
      || el.getAttribute('role');
    if (!interactive) continue;
    out.push({
      tag, id: el.id || null, type,
      cls: (typeof el.className === 'string') ? el.className.slice(0, 70) : null,
      name: el.getAttribute('name'),
      forAttr: el.getAttribute('for'),
      text: (el.innerText || el.value || '').trim().slice(0, 30) || null,
      top: Math.round(rect.top),
    });
  }
  return out;
}
"""


def main() -> int:
    config = load_config()
    blog_url = config["blog_url"].rstrip("/")
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)

    with open_context(headless=True) as context:
        page = context.pages[0] if context.pages else context.new_page()

        # 다이얼로그를 삼키지 말고 내용을 찍는다 (빈 제목 경고 등을 놓치지 않도록)
        def on_dialog(dialog):
            print(f"  [다이얼로그] {dialog.type}: {dialog.message}")
            dialog.dismiss()

        page.on("dialog", on_dialog)
        page.goto(f"{blog_url}/manage/newpost/", wait_until="domcontentloaded")
        if "/auth/login" in page.url:
            print("[실패] 로그인이 필요합니다.")
            return 1
        page.wait_for_timeout(6000)

        # 제목/본문이 비면 '완료'가 경고만 띄우고 레이어를 안 연다.
        page.fill("#post-title-inp", "[조사용] 발행 레이어 확인")
        body = page.frame_locator("#editor-tistory_ifr").locator("body")
        body.click()
        page.keyboard.type("조사용 본문입니다.")
        page.wait_for_timeout(1000)

        before = page.evaluate(_SCAN)
        seen = {(item["tag"], item["id"], item["text"]) for item in before}

        # 발행 레이어: 보이는 '완료' 버튼만 클릭
        target = page.locator("#publish-layer-btn:visible").first
        if target.count() == 0:
            target = page.get_by_role("button", name="완료").first
        target.click()
        page.wait_for_timeout(2500)

        after = page.evaluate(_SCAN)
        added = [
            item for item in after
            if (item["tag"], item["id"], item["text"]) not in seen
        ]

        print(f"===== 발행 레이어에서 새로 나타난 요소 {len(added)}개 =====")
        for item in added:
            print(
                f"  {item['tag']:9} id={str(item['id'])[:26]:28} "
                f"type={str(item['type'])[:6]:8} for={str(item['forAttr'])[:12]:14} "
                f"text={str(item['text'])[:26]}"
            )

        page.screenshot(path=str(DEBUG_DIR / "publish-layer.png"), full_page=True)
        (DEBUG_DIR / "publish-layer.json").write_text(
            json.dumps(added, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"\n[완료] {DEBUG_DIR / 'publish-layer.png'}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
