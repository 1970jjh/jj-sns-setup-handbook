"""비공개로 올려둔 글을 공개로 일괄 전환한다.

    python src/make_public.py            # 비공개 글 전부 (일일 한도만큼)
    python src/make_public.py --limit 5

배경: 티스토리는 **하루 15건까지만 '공개 발행'**을 허용한다(실측). 비공개 발행은 한도에
걸리지 않으므로, 한도를 다 쓴 날에는 비공개로 올려두고 다음날 이 스크립트로 공개 전환한다.

전환도 '공개 발행'으로 계산되므로 하루 15건 상한이 그대로 적용된다.
한도에 걸리면 남은 글은 그대로 두고 멈춘다 — 다음날 다시 실행하면 이어서 처리된다.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import load_config, open_context  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"
DAILY_LIMIT_MARK = "하루에 새롭게 공개 발행할 수 있는 글"

# 글 관리 목록에서 비공개 글의 체크박스를 찾아 켠다.
# 비공개 글은 행에 '비공개' 표시가 붙는다.
_CHECK_PRIVATE = """
(limit) => {
  const boxes = Array.from(document.querySelectorAll('input[type=checkbox]'));
  let picked = 0;
  const titles = [];
  for (const box of boxes) {
    if (picked >= limit) break;
    const row = box.closest('li, tr, div[class*=item], div[class*=list]');
    if (!row) continue;
    const text = (row.innerText || '');
    // 헤더(전체선택) 행은 제목이 없다
    if (!text.includes('비공개')) continue;
    if (row.querySelectorAll('input[type=checkbox]').length > 1) continue;
    box.click();
    picked += 1;
    titles.push(text.split('\\n')[0].trim().slice(0, 50));
  }
  return titles;
}
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="비공개 글 일괄 공개 전환")
    parser.add_argument("--limit", type=int, default=15, help="한 번에 전환할 최대 건수")
    args = parser.parse_args()

    config = load_config()
    blog_url = config["blog_url"].rstrip("/")
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    alerts: list[str] = []

    with open_context(headless=True) as context:
        page = context.pages[0] if context.pages else context.new_page()

        def on_dialog(dialog):
            alerts.append(dialog.message)
            print(f"  [알림창] {dialog.message[:100]}")
            dialog.accept()

        page.on("dialog", on_dialog)
        page.goto(f"{blog_url}/manage/posts/", wait_until="domcontentloaded")
        if "/auth/login" in page.url:
            print("[실패] 로그인이 필요합니다. python src/login.py 를 실행하세요.")
            return 1
        page.wait_for_timeout(4000)

        picked = page.evaluate(_CHECK_PRIVATE, args.limit)
        if not picked:
            print("전환할 비공개 글이 없습니다.")
            return 0

        print(f"공개 전환 대상 {len(picked)}건")
        for title in picked:
            print(f"  - {title}")
        page.wait_for_timeout(1200)

        change = page.locator("button.btn_opt", has_text="변경").first
        if change.count() == 0:
            page.screenshot(path=str(DEBUG_DIR / "fail-공개전환-변경버튼.png"), full_page=True)
            print("[실패] '변경' 버튼을 찾지 못했습니다.")
            return 1
        change.click(force=True)
        page.wait_for_timeout(1500)

        # 메뉴 항목은 <label class="lab_btn">공개<input type="button"></label> 구조다.
        item = page.locator("ul.list_opt label.lab_btn").filter(has_text="공개").first
        if item.count() == 0:
            page.screenshot(path=str(DEBUG_DIR / "fail-공개전환-메뉴.png"), full_page=True)
            print("[실패] '공개' 메뉴를 찾지 못했습니다.")
            return 1
        item.click(force=True)
        page.wait_for_timeout(6000)

        if any(DAILY_LIMIT_MARK in message for message in alerts):
            print("\n[중단] 일일 공개 발행 한도(15건)에 걸렸습니다. 내일 다시 실행하세요.")
            return 2

        page.goto(f"{blog_url}/manage/posts/", wait_until="domcontentloaded")
        page.wait_for_timeout(3500)
        remaining = page.evaluate(
            "() => (document.body.innerText.match(/비공개/g) || []).length"
        )
        print(f"\n[완료] 전환 요청 처리됨. 남은 비공개 표시: {remaining}건")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
