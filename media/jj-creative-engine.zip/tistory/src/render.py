"""원고 JSON을 티스토리 에디터에 넣을 HTML로 변환한다.

이미지는 실제 업로드 후 티스토리가 만들어준 <figure> 마크업으로 치환해야 하므로,
여기서는 자리표시자만 남긴다. 치환은 publish.py가 담당한다.
"""

from __future__ import annotations

import html
import json
import re
from pathlib import Path

IMAGE_PLACEHOLDER = "<!--TISTORY_IMAGE_{index}-->"

_ALLOWED_BLOCKS = {"h2", "h3", "p", "ul", "ol", "quote", "image", "hr", "code", "embed"}


class ManuscriptError(ValueError):
    """원고 JSON이 스키마에 맞지 않을 때."""


def load_manuscript(path: Path) -> dict:
    """원고 JSON을 읽고 최소 스키마를 검증한다."""
    try:
        with path.open(encoding="utf-8") as fp:
            data = json.load(fp)
    except FileNotFoundError:
        raise ManuscriptError(f"원고 파일이 없습니다: {path}") from None
    except json.JSONDecodeError as error:
        raise ManuscriptError(f"원고 JSON 형식 오류 ({path}): {error}") from error

    if not isinstance(data, dict):
        raise ManuscriptError("원고 최상위는 객체여야 합니다.")

    title = data.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ManuscriptError("title이 비어 있습니다.")

    blocks = data.get("blocks")
    if not isinstance(blocks, list) or not blocks:
        raise ManuscriptError("blocks가 비어 있습니다.")

    slug = data.get("slug", "")
    if slug and not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,79}", slug):
        raise ManuscriptError(
            f"slug '{slug}'가 올바르지 않습니다. "
            "영문 소문자·숫자·하이픈만, 80자 이내로 써주세요."
        )

    for position, block in enumerate(blocks):
        if not isinstance(block, dict):
            raise ManuscriptError(f"blocks[{position}]는 객체여야 합니다.")
        kind = block.get("type")
        if kind not in _ALLOWED_BLOCKS:
            raise ManuscriptError(
                f"blocks[{position}]의 type '{kind}'을 지원하지 않습니다. "
                f"지원: {sorted(_ALLOWED_BLOCKS)}"
            )
        if kind == "image":
            image_path = block.get("path")
            if not image_path:
                raise ManuscriptError(f"blocks[{position}] image에 path가 없습니다.")
            if not Path(image_path).is_file():
                raise ManuscriptError(
                    f"blocks[{position}] 이미지 파일을 찾을 수 없습니다: {image_path}"
                )

    return data


def collect_images(manuscript: dict) -> list[dict]:
    """본문 등장 순서대로 이미지 블록 목록을 만든다."""
    images = []
    for block in manuscript["blocks"]:
        if block.get("type") == "image":
            images.append(
                {
                    "path": str(Path(block["path"]).resolve()),
                    "alt": block.get("alt", ""),
                    "caption": block.get("caption", ""),
                }
            )
    return images


def render_html(manuscript: dict) -> str:
    """원고를 티스토리 HTML 모드용 마크업으로 변환한다.

    이미지는 <!--TISTORY_IMAGE_n--> 자리표시자로 남는다.
    """
    parts: list[str] = []
    image_index = 0

    for block in manuscript["blocks"]:
        kind = block["type"]

        if kind == "image":
            parts.append(IMAGE_PLACEHOLDER.format(index=image_index))
            image_index += 1
        elif kind in ("h2", "h3"):
            parts.append(f"<{kind}>{_escape(block.get('text', ''))}</{kind}>")
        elif kind == "p":
            parts.append(f"<p>{_inline(block.get('text', ''))}</p>")
        elif kind in ("ul", "ol"):
            items = "".join(
                f"<li>{_inline(item)}</li>" for item in block.get("items", [])
            )
            parts.append(f"<{kind}>{items}</{kind}>")
        elif kind == "quote":
            parts.append(f"<blockquote><p>{_inline(block.get('text', ''))}</p></blockquote>")
        elif kind == "code":
            parts.append(f"<pre><code>{_escape(block.get('text', ''))}</code></pre>")
        elif kind == "hr":
            parts.append("<hr />")
        elif kind == "embed":
            # 유튜브 등 iframe 임베드. html을 직접 넣거나 youtube_id로 자동 생성.
            raw = block.get("html")
            if not raw and block.get("youtube_id"):
                yid = block["youtube_id"]
                raw = (
                    '<figure class="imageblock alignCenter">'
                    '<span style="display:block;position:relative;padding-top:56.25%;">'
                    f'<iframe src="https://www.youtube.com/embed/{yid}" '
                    'frameborder="0" allowfullscreen '
                    'style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>'
                    '</span></figure>'
                )
            parts.append(raw or "")

    return "\n".join(parts)


def _escape(text: str) -> str:
    return html.escape(str(text), quote=False)


def _inline(text: str) -> str:
    """줄바꿈만 <br>로 살리고 나머지는 이스케이프한다.

    원고에서 **굵게** 같은 마크다운은 쓰지 않는다는 전제.
    """
    escaped = _escape(text)
    return escaped.replace("\n", "<br />")
