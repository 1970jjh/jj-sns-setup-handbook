"""티스토리 브라우저 세션 관리.

카카오 로그인은 API가 없으므로 Playwright persistent context(브라우저 프로필)에
쿠키를 통째로 보관해 재사용한다. 프로필 디렉터리는 .gitignore 대상이다.
"""

from __future__ import annotations

import json
import time
import os
from pathlib import Path

from playwright.sync_api import BrowserContext, sync_playwright

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# 크롬 프로필은 한 번에 한 프로세스만 열 수 있다. 발행을 병렬로 돌리려면
# TISTORY_PROFILE 환경변수로 복제된 프로필을 지정한다 (쿠키는 state.json에서 복원).
_PROFILE_NAME = os.environ.get("TISTORY_PROFILE", "chrome-profile")
AUTH_DIR = PROJECT_ROOT / ".auth" / _PROFILE_NAME
STATE_PATH = PROJECT_ROOT / ".auth" / "state.json"
CONFIG_PATH = PROJECT_ROOT / "config.json"

# 헤드리스 티가 나면 카카오가 추가 인증을 요구하므로 일반 브라우저처럼 위장한다.
_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

_LAUNCH_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-features=IsolateOrigins,site-per-process",
]


def load_config() -> dict:
    """config.json을 읽어 설정 dict를 돌려준다."""
    try:
        with CONFIG_PATH.open(encoding="utf-8") as fp:
            return json.load(fp)
    except FileNotFoundError:
        raise SystemExit(
            f"설정 파일이 없습니다: {CONFIG_PATH}\n"
            "config.json을 만들고 blog_url을 채워주세요."
        )
    except json.JSONDecodeError as error:
        raise SystemExit(f"config.json 형식이 잘못되었습니다: {error}") from error


def open_context(headless: bool | None = None, slow_mo: int | None = None):
    """저장된 로그인 프로필로 브라우저 컨텍스트를 연다.

    사용법:
        with open_context() as (playwright, context):
            page = context.pages[0] if context.pages else context.new_page()
    """
    config = load_config()
    AUTH_DIR.mkdir(parents=True, exist_ok=True)

    resolved_headless = config.get("headless", True) if headless is None else headless
    resolved_slow_mo = config.get("slow_mo_ms", 0) if slow_mo is None else slow_mo

    return _ContextManager(
        headless=resolved_headless,
        slow_mo=resolved_slow_mo,
        timeout=config.get("timeout_ms", 45000),
    )


class _ContextManager:
    """sync_playwright + persistent context를 한 번에 열고 닫는 컨텍스트 매니저."""

    def __init__(self, headless: bool, slow_mo: int, timeout: int) -> None:
        self._headless = headless
        self._slow_mo = slow_mo
        self._timeout = timeout
        self._playwright = None
        self._context: BrowserContext | None = None

    def __enter__(self) -> BrowserContext:
        self._playwright = sync_playwright().start()
        try:
            # JJ_RECORD_VIDEO_DIR 이 있으면 브라우저 컨텍스트 영상을 남긴다.
            # ⚠️ 화면 녹화와 달리 다른 창이 섞이지 않으므로 시연 영상은 이쪽을 쓴다.
            record = {}
            video_dir = os.environ.get("JJ_RECORD_VIDEO_DIR")
            if video_dir:
                Path(video_dir).mkdir(parents=True, exist_ok=True)
                record = {
                    "record_video_dir": video_dir,
                    "record_video_size": {"width": 1440, "height": 960},
                }
            self._context = self._playwright.chromium.launch_persistent_context(
                user_data_dir=str(AUTH_DIR),
                headless=self._headless,
                slow_mo=self._slow_mo,
                args=_LAUNCH_ARGS,
                user_agent=_UA,
                viewport={"width": 1440, "height": 960},
                locale="ko-KR",
                timezone_id="Asia/Seoul",
                **record,
            )
        except Exception as error:
            self._playwright.stop()
            raise RuntimeError(
                "브라우저를 열지 못했습니다. 크롬 프로필이 다른 프로세스에서 "
                f"사용 중인지 확인하세요 ({AUTH_DIR}). 원인: {error}"
            ) from error

        self._context.set_default_timeout(self._timeout)
        restore_cookies(self._context)
        return self._context

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self._context is not None:
            # 🔴 나갈 때마다 백업을 갱신한다 (2026-08-03).
            # 카카오는 사용 중에 쿠키를 계속 갱신하는데, 예전에는 login.py에서만
            # 백업해 두고 그 스냅샷을 매번 되심었다. 그래서 로그인 직후 만들어진
            # 짧은 쿠키가 만료된 뒤에는, 프로필에 살아 있던 최신 쿠키까지
            # 죽은 값으로 덮어써 매 작업마다 재로그인을 하게 됐다.
            try:
                save_state(self._context)
            except Exception:
                pass
            try:
                self._context.close()
            except Exception:
                pass
        if self._playwright is not None:
            self._playwright.stop()


def save_state(context: BrowserContext) -> None:
    """로그인 쿠키를 state.json에 백업한다.

    카카오/티스토리 로그인 쿠키 일부는 브라우저를 닫으면 사라지는 '세션 쿠키'라
    크롬 프로필만으로는 재로그인 없이 못 쓴다. storage_state는 세션 쿠키까지
    포함하므로 이를 따로 떠 두었다가 다음 실행 때 다시 심는다.
    """
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        context.storage_state(path=str(STATE_PATH))
    except Exception as error:
        print(f"  [경고] 세션 백업에 실패했습니다: {error}")


def restore_cookies(context: BrowserContext) -> None:
    """save_state가 떠 둔 쿠키를 컨텍스트에 다시 심는다.

    이미 만료된 쿠키는 심지 않는다. 심으면 크롬 프로필에 살아 있던 최신 쿠키를
    죽은 값으로 덮어써 멀쩡한 세션이 끊긴다 (2026-08-03 실측).
    """
    if not STATE_PATH.is_file():
        return
    try:
        with STATE_PATH.open(encoding="utf-8") as fp:
            cookies = json.load(fp).get("cookies") or []
    except (json.JSONDecodeError, OSError) as error:
        print(f"  [경고] 세션 백업을 읽지 못했습니다: {error}")
        return

    now = time.time()
    dropped = len(cookies)
    cookies = [c for c in cookies if c.get("expires", -1) <= 0 or c["expires"] > now]
    dropped -= len(cookies)
    if dropped:
        print(f"  (만료된 쿠키 {dropped}개는 복원하지 않았습니다)")

    if not cookies:
        return
    try:
        context.add_cookies(cookies)
    except Exception as error:
        print(f"  [경고] 세션 쿠키 복원에 실패했습니다: {error}")


def is_logged_in(context: BrowserContext, blog_url: str) -> bool:
    """관리 페이지 접근이 되는지로 로그인 상태를 판정한다."""
    page = context.pages[0] if context.pages else context.new_page()
    try:
        page.goto(f"{blog_url}/manage", wait_until="domcontentloaded")
    except Exception:
        return False
    return "/auth/login" not in page.url
