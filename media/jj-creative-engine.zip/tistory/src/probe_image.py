"""이미지 업로드 경로를 실제로 시험한다 (발행은 하지 않음).

    python src/probe_image.py <이미지경로>

툴바 사진 버튼 → 파일 선택창 → 업로드 후 본문 iframe에 삽입된 마크업을 찍는다.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import load_config, open_context  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"

# 툴바 첫 번째 항목이 사진/동영상 드롭다운이다.
_IMAGE_BUTTON_CANDIDATES = [
    "#attach-layer-btn:visible",
    "#mceu_0-open:visible",
    "#mceu_0-button:visible",
]


def main() -> int:
    if len(sys.argv) < 2:
        print("사용법: python src/probe_image.py <이미지경로>")
        return 1
    image_path = Path(sys.argv[1]).resolve()
    if not image_path.is_file():
        print(f"[실패] 이미지가 없습니다: {image_path}")
        return 1

    config = load_config()
    blog_url = config["blog_url"].rstrip("/")
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)

    with open_context(headless=True) as context:
        page = context.pages[0] if context.pages else context.new_page()
        page.on("dialog", lambda dialog: (print(f"  [다이얼로그] {dialog.message[:60]}"), dialog.dismiss()))
        page.goto(f"{blog_url}/manage/newpost/", wait_until="domcontentloaded")
        if "/auth/login" in page.url:
            print("[실패] 로그인이 필요합니다.")
            return 1
        page.wait_for_timeout(6000)

        frame = page.frame_locator("#editor-tistory_ifr").locator("body")
        before = frame.inner_html()
        print(f"업로드 전 본문: {before[:80]}")

        # 툴바 드롭다운을 연 뒤 '사진' 항목을 눌러야 파일 선택창이 뜬다.
        clicked = None
        for candidate in _IMAGE_BUTTON_CANDIDATES:
            locator = page.locator(candidate).first
            if locator.count() == 0:
                continue
            try:
                locator.click()
                page.wait_for_timeout(800)
                photo = page.get_by_text("사진", exact=True).first
                with page.expect_file_chooser(timeout=8000) as chooser_info:
                    photo.click()
                chooser_info.value.set_files(str(image_path))
                clicked = candidate
                print(f"[성공] {candidate} → '사진' → 파일 선택창 열림")
                break
            except Exception as error:
                print(f"  [시도] {candidate} -> {type(error).__name__}: {str(error)[:70]}")

        if clicked is None:
            page.screenshot(path=str(DEBUG_DIR / "image-probe-fail.png"), full_page=True)
            print(f"[실패] 파일 선택창을 못 열었습니다. {DEBUG_DIR / 'image-probe-fail.png'} 확인")
            return 1

        page.wait_for_timeout(8000)  # 업로드 + 삽입 대기
        after = frame.inner_html()
        (DEBUG_DIR / "after-image.html").write_text(after, encoding="utf-8")
        page.screenshot(path=str(DEBUG_DIR / "after-image.png"), full_page=True)

        print("\n===== 업로드 후 본문 HTML =====")
        print(after[:1200])
        print(f"\n[완료] {DEBUG_DIR / 'after-image.html'}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
