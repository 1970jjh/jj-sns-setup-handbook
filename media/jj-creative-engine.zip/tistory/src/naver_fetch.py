"""네이버 블로그 포스팅을 구조화해 가져온다 (본문 + 이미지 다운로드 + 사진/그래픽 분류).

    python src/naver_fetch.py --index 11 20     # RSS 최신순 11~20번
    python src/naver_fetch.py --yesterday       # 전날 올라온 글 (매일 자동화용)
    python src/naver_fetch.py --days 3          # 최근 3일

결과: work/<logNo>/source.json + work/<logNo>/images/*.jpg
source.json 을 읽고 티스토리용으로 리라이팅하는 것은 Claude가 한다.
"""

from __future__ import annotations

import argparse
import html as html_lib
import json
import re
import sys
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import sync_state  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
WORK_DIR = PROJECT_ROOT / "work"

BLOG_ID = "YOUR_NAVER_BLOG_ID"
RSS_URL = f"https://rss.blog.naver.com/{BLOG_ID}.xml"
POST_URL = (
    "https://blog.naver.com/PostView.naver?blogId={blog}&logNo={log}"
    "&redirect=Dlog&widgetTypeCall=true&directAccess=false"
)
KST = timezone(timedelta(hours=9))

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Referer": "https://blog.naver.com/",
}

# 사진 판별 기준: 축소본의 고유 색 수. 실사는 색이 풍부하고 도표/텍스트 이미지는 단조롭다.
PHOTO_COLOR_THRESHOLD = 3000


def fetch(url: str, timeout: int = 30) -> bytes:
    request = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


# ------------------------------------------------------------------ RSS


def list_posts() -> list[dict]:
    """RSS에서 최신순 글 목록을 만든다."""
    raw = fetch(RSS_URL).decode("utf-8", errors="ignore")
    posts = []
    for item in re.findall(r"<item>(.*?)</item>", raw, re.S):
        title = _cdata(item, "title")
        link = _cdata(item, "link")
        pub = re.search(r"<pubDate>(.*?)</pubDate>", item, re.S)
        log_no = re.search(r"/(\d+)\?", link or "")
        if not (title and link and log_no):
            continue
        posts.append(
            {
                "title": html_lib.unescape(title),
                "link": link.split("?")[0],
                "log_no": log_no.group(1),
                "published": _parse_date(pub.group(1) if pub else ""),
            }
        )
    return posts


def _cdata(block: str, tag: str) -> str | None:
    found = re.search(rf"<{tag}><!\[CDATA\[(.*?)\]\]></{tag}>", block, re.S)
    return found.group(1).strip() if found else None


def _parse_date(text: str) -> str:
    """RSS pubDate → KST 기준 YYYY-MM-DD."""
    for fmt in ("%a, %d %b %Y %H:%M:%S %z", "%a, %d %b %Y %H:%M:%S"):
        try:
            parsed = datetime.strptime(text.strip(), fmt)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=KST)
            return parsed.astimezone(KST).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return ""


# ------------------------------------------------------------------ 본문 파싱

_COMPONENT = re.compile(r'<div class="se-component[^"]*"[^>]*>(.*?)(?=<div class="se-component|\Z)', re.S)
_TEXT_SPAN = re.compile(r'<span[^>]*class="se-fs[^"]*"[^>]*>(.*?)</span>', re.S)
_IMG_SRC = re.compile(r'data-lazy-src="([^"]+)"')
_TAG = re.compile(r"<[^>]+>")


def parse_post(raw_html: str) -> list[dict]:
    """본문을 등장 순서대로 [{'type':'text'|'image', ...}] 로 만든다."""
    container = re.search(
        r'<div class="se-main-container">(.*?)<!-- // \S*\s*SE3', raw_html, re.S
    ) or re.search(r'<div class="se-main-container">(.*)', raw_html, re.S)
    body = container.group(1) if container else raw_html

    blocks: list[dict] = []
    for chunk in _COMPONENT.findall(body):
        image = _IMG_SRC.search(chunk)
        if image:
            blocks.append({"type": "image", "url": image.group(1)})
            continue
        lines = []
        for span in _TEXT_SPAN.findall(chunk):
            text = html_lib.unescape(_TAG.sub("", span))
            text = text.replace("​", "").replace("&nbsp;", " ").strip()
            if text:
                lines.append(text)
        if lines:
            blocks.append({"type": "text", "lines": lines})
    return blocks


# ------------------------------------------------------------------ 이미지


def download_images(blocks: list[dict], target_dir: Path) -> None:
    """이미지를 내려받고 실사/그래픽을 분류해 블록에 기록한다."""
    target_dir.mkdir(parents=True, exist_ok=True)
    index = 0
    for block in blocks:
        if block["type"] != "image":
            continue
        base = block["url"].split("?")[0]
        suffix = Path(base).suffix.lower() or ".jpg"
        if suffix not in (".jpg", ".jpeg", ".png", ".gif", ".webp"):
            suffix = ".jpg"
        path = target_dir / f"{index:02d}{suffix}"
        try:
            path.write_bytes(fetch(f"{base}?type=w966"))
        except Exception as error:
            block["error"] = str(error)
            print(f"    [경고] 이미지 다운로드 실패: {error}")
            index += 1
            continue
        block["path"] = str(path)
        block["is_photo"], block["colors"] = _looks_like_photo(path)
        index += 1


def _looks_like_photo(path: Path) -> tuple[bool, int]:
    """실사 사진인지 도표/텍스트 이미지인지 색 다양성으로 판단한다."""
    try:
        from PIL import Image

        with Image.open(path) as image:
            sample = image.convert("RGB").resize((120, 120))
            colors = len(set(sample.get_flattened_data() if hasattr(sample, "get_flattened_data") else sample.getdata()))
        return colors >= PHOTO_COLOR_THRESHOLD, colors
    except Exception:
        return True, -1  # 판단 불가 시 사진으로 보고 그대로 재사용


# ------------------------------------------------------------------ 실행


def harvest(posts: list[dict]) -> list[Path]:
    saved = []
    for order, post in enumerate(posts, 1):
        print(f"[{order}/{len(posts)}] {post['title'][:50]}")
        target = WORK_DIR / post["log_no"]
        target.mkdir(parents=True, exist_ok=True)
        try:
            raw = fetch(POST_URL.format(blog=BLOG_ID, log=post["log_no"])).decode(
                "utf-8", errors="ignore"
            )
        except Exception as error:
            print(f"    [실패] 본문을 가져오지 못했습니다: {error}")
            continue

        blocks = parse_post(raw)
        download_images(blocks, target / "images")

        photos = sum(1 for b in blocks if b.get("is_photo"))
        graphics = sum(1 for b in blocks if b["type"] == "image" and not b.get("is_photo"))
        words = sum(len(" ".join(b["lines"])) for b in blocks if b["type"] == "text")
        print(f"    본문 {words}자 / 실사 {photos}장 / 그래픽 {graphics}장")

        record = {**post, "blocks": blocks}
        out = target / "source.json"
        out.write_text(json.dumps(record, ensure_ascii=False, indent=1), encoding="utf-8")
        saved.append(out)
    return saved


def main() -> int:
    parser = argparse.ArgumentParser(description="네이버 블로그 원문 수집")
    parser.add_argument("--index", nargs=2, type=int, metavar=("FROM", "TO"),
                        help="RSS 최신순 순번 범위 (1부터)")
    parser.add_argument("--yesterday", action="store_true", help="전날 올라온 글만")
    parser.add_argument("--days", type=int, help="최근 N일 이내 글")
    parser.add_argument("--pending", action="store_true",
                        help="아직 티스토리에 발행되지 않은 글 전부 (매일 자동화 기본값)")
    parser.add_argument("--limit", type=int, default=0,
                        help="--pending 사용 시 한 번에 처리할 최대 건수 (0=제한 없음)")
    args = parser.parse_args()

    posts = list_posts()
    if not posts:
        print("[실패] RSS에서 글을 찾지 못했습니다.")
        return 1

    if args.pending:
        # 노트북이 며칠 꺼져 있었어도 그 사이 글을 전부 따라잡는다.
        selected = sync_state.pending(posts)
        if args.limit:
            selected = selected[: args.limit]
        print(sync_state.summary())
    elif args.index:
        start, end = args.index
        selected = posts[start - 1 : end]
    elif args.yesterday:
        target = (datetime.now(KST) - timedelta(days=1)).strftime("%Y-%m-%d")
        selected = [p for p in posts if p["published"] == target]
        print(f"기준일: {target}")
    elif args.days:
        limit = (datetime.now(KST) - timedelta(days=args.days)).strftime("%Y-%m-%d")
        selected = [p for p in posts if p["published"] >= limit]
    else:
        print("[실패] --pending / --index / --yesterday / --days 중 하나를 지정하세요.")
        return 1

    if not selected:
        print("대상 글이 없습니다.")
        return 0

    print(f"대상 {len(selected)}건\n")
    saved = harvest(selected)
    print(f"\n[완료] {len(saved)}건 저장 → {WORK_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
