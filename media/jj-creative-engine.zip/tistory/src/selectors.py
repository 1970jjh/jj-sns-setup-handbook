"""티스토리 에디터 셀렉터 — 실측 확정본.

확인일: 2026-07-30 / YOUR_TISTORY_ID.tistory.com/manage/newpost/
확인 방법: src/inspect_editor.py, src/probe_menus.py, src/probe_publish.py, src/probe_image.py

에디터가 개편되면 위 조사 스크립트를 다시 돌려 이 파일만 갱신하면 된다.
"""

from __future__ import annotations

# --- 본문 -------------------------------------------------------------------
# 본문은 TinyMCE iframe 안에 있다. 텍스트 주입은 DOM이 아니라
# tinymce.activeEditor.setContent()로 해야 티스토리가 변경을 인식한다.
# (CodeMirror(HTML 모드) setValue는 모드 전환 시 내용이 날아간다 — 실측 확인)
BODY_IFRAME = "#editor-tistory_ifr"

# --- 제목 -------------------------------------------------------------------
TITLE_INPUT = "#post-title-inp"

# --- 이미지 첨부 -------------------------------------------------------------
# 툴바 첫 항목(드롭다운)을 열면 사진/파일/슬라이드쇼가 나온다. '사진'을 눌러야
# 파일 선택창이 뜬다. 페이지에 상시 file input은 없다 (실측: 0개).
ATTACH_DROPDOWN = "#mceu_0-open:visible"
ATTACH_PHOTO_ITEM = "사진"  # get_by_text(exact=True)로 찾는다

# --- 에디터 모드 -------------------------------------------------------------
MODE_DROPDOWN_OPEN = "#editor-mode-layer-btn-open"
MODE_BASIC = "#editor-mode-kakao"
MODE_MARKDOWN = "#editor-mode-markdown"
MODE_HTML = "#editor-mode-html"

# --- 태그 -------------------------------------------------------------------
TAG_INPUT = "#tagText"

# --- 카테고리 ---------------------------------------------------------------
CATEGORY_OPEN = "#category-btn"

# --- 발행 -------------------------------------------------------------------
PUBLISH_LAYER_OPEN = "#publish-layer-btn"   # '완료' — 제목이 비면 경고만 뜨고 안 열림
PUBLISH_CONFIRM = "#publish-btn"            # '공개 발행'
PUBLISH_CANCEL = "#unpublish-btn"
URL_SLUG_INPUT = "#urlPublish"

VISIBILITY = {
    "public": "#open20",
    "protected": "#open15",
    "private": "#open0",
}
