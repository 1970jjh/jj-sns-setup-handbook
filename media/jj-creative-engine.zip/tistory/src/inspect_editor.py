"""티스토리 글쓰기 에디터의 DOM 구조를 덤프한다.

티스토리는 공식 API가 없어 에디터 DOM에 의존한다. 카카오가 에디터를 개편하면
셀렉터가 깨지므로, 이 스크립트로 실제 DOM을 떠서 selectors.py를 갱신한다.

    python src/inspect_editor.py

결과: debug/editor-dump.json, debug/editor.png, debug/editor.html
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.session import load_config, open_context  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEBUG_DIR = PROJECT_ROOT / "debug"

# 에디터에서 의미 있는 후보만 추린다 (input/button/편집영역).
_PROBE_SCRIPT = """
() => {
  const pick = (el) => ({
    tag: el.tagName.toLowerCase(),
    id: el.id || null,
    cls: (el.className && typeof el.className === 'string')
        ? el.className.slice(0, 120) : null,
    type: el.getAttribute('type'),
    role: el.getAttribute('role'),
    ariaLabel: el.getAttribute('aria-label'),
    placeholder: el.getAttribute('placeholder'),
    text: (el.innerText || '').trim().slice(0, 40) || null,
    contenteditable: el.getAttribute('contenteditable'),
  });

  const sel = 'input, textarea, button, [contenteditable], [role="button"], .CodeMirror';
  const nodes = Array.from(document.querySelectorAll(sel));
  return {
    url: location.href,
    title: document.title,
    iframes: Array.from(document.querySelectorAll('iframe'))
      .map(f => ({ id: f.id || null, src: (f.src || '').slice(0, 120) })),
    elements: nodes.map(pick),
  };
}
"""


def main() -> int:
    config = load_config()
    blog_url = config["blog_url"].rstrip("/")
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)

    # 실제 발행이 헤드리스로 돌므로 같은 조건에서 DOM을 뜬다.
    with open_context(headless=True) as context:
        page = context.pages[0] if context.pages else context.new_page()

        # "이어서 작성하시겠습니까?" 등 임시저장 복구 다이얼로그를 자동으로 거절한다.
        page.on("dialog", lambda dialog: dialog.dismiss())

        try:
            page.goto(f"{blog_url}/manage/newpost/", wait_until="domcontentloaded")
        except Exception as error:
            print(f"[실패] 에디터를 열지 못했습니다: {error}")
            return 1

        if "/auth/login" in page.url:
            print("[실패] 로그인이 필요합니다. 먼저 python src/login.py 를 실행하세요.")
            return 1

        page.wait_for_timeout(6000)  # 에디터 JS가 늦게 뜬다

        try:
            dump = page.evaluate(_PROBE_SCRIPT)
        except Exception as error:
            print(f"[실패] DOM을 읽지 못했습니다: {error}")
            return 1

        (DEBUG_DIR / "editor-dump.json").write_text(
            json.dumps(dump, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (DEBUG_DIR / "editor.html").write_text(page.content(), encoding="utf-8")
        page.screenshot(path=str(DEBUG_DIR / "editor.png"), full_page=True)

        print(f"[완료] {len(dump['elements'])}개 요소를 덤프했습니다.")
        print(f"  - {DEBUG_DIR / 'editor-dump.json'}")
        print(f"  - {DEBUG_DIR / 'editor.png'}")
        print(f"  - {DEBUG_DIR / 'editor.html'}")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
