"""쇼츠 script.json의 씬 길이를 실제 발화 길이에 맞춘다 (무음 제거).

    python src/shorts_fit.py <프로젝트경로>

배경 — 씬 길이를 사람이 미리 정하면 내레이션보다 길어진 만큼 그대로 정적이 된다.
실제로 54초 영상에 무음이 19.5초(36%) 생긴 적이 있다. 쇼츠에서는 치명적이다.

🔴 subtitles.json으로 발화 길이를 재면 안 된다 (2026-07-30 실패)
   자막 타임코드는 **패딩까지 포함한 연속 구간**이라(앞 항목 end == 다음 항목 start)
   거기서 발화 끝을 역산하면 매번 어긋나고, 보정→재생성을 반복해도 수렴하지 않는다.
   반드시 **narration_full.mp3를 silencedetect로 직접 측정**한다.

동작:
  1) 현재 duration_sec 누적으로 씬 구간을 나눈다 (오디오는 이 길이로 만들어져 있다)
  2) 각 구간에서 **마지막 발화가 끝나는 시각**을 무음 감지로 찾는다
  3) duration_sec = 발화길이 + TAIL_PAD 로 다시 쓴다
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

MAX_GAP = 2.0      # 허용 무음 상한 (사용자 확정: 1.5초는 TTS 문장 경계에서 빡빡해 2.0으로 완화)
TAIL_PAD = 0.25    # 문장 끝 여운
MIN_SCENE = 2.5    # 너무 짧으면 화면이 튄다
SILENCE_DB = -35   # 무음 판정 기준
SILENCE_MIN = 0.35 # 이 이상 조용하면 무음 구간으로 본다


def silence_ranges(audio: Path) -> list[tuple[float, float]]:
    """오디오에서 무음 구간 [(시작, 끝), ...] 을 뽑는다."""
    result = subprocess.run(
        ["ffmpeg", "-i", str(audio), "-af",
         f"silencedetect=noise={SILENCE_DB}dB:d={SILENCE_MIN}", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    log = result.stderr
    starts = [float(m) for m in re.findall(r"silence_start: ([0-9.]+)", log)]
    ends = [float(m) for m in re.findall(r"silence_end: ([0-9.]+)", log)]
    return list(zip(starts, ends + [starts[-1] + 999] if len(ends) < len(starts) else ends))


def speech_end(start: float, end: float, silences: list[tuple[float, float]]) -> float:
    """구간 [start, end) 안에서 마지막 발화가 끝나는 시각."""
    # 구간 끝에 걸쳐 있는 무음이 있으면 그 무음이 시작되는 지점이 발화 끝이다.
    for s_start, s_end in silences:
        if s_start <= end <= s_end + 0.05 and s_start > start:
            return s_start
    return end


def main() -> int:
    parser = argparse.ArgumentParser(description="씬 길이를 실제 발화에 맞춤")
    parser.add_argument("project", type=Path, help="script.json이 있는 폴더")
    args = parser.parse_args()

    script_path = args.project / "script.json"
    audio_path = args.project / "narration_full.mp3"
    for path in (script_path, audio_path):
        if not path.is_file():
            print(f"[실패] 파일이 없습니다: {path}")
            return 1

    script = json.loads(script_path.read_text(encoding="utf-8"))
    scenes = script.get("scenes", [])
    if not scenes:
        print("[실패] scenes가 비어 있습니다.")
        return 1

    silences = silence_ranges(audio_path)
    print(f"씬 {len(scenes)}개 / 무음 구간 {len(silences)}개 감지\n")

    cursor, total_before, total_after = 0.0, 0.0, 0.0
    for scene in scenes:
        start = cursor
        planned = float(scene.get("duration_sec", 10))
        end = start + planned
        cursor = end
        total_before += planned

        spoken = speech_end(start, end, silences) - start
        fitted = max(MIN_SCENE, round(spoken + TAIL_PAD, 1))
        gap = planned - spoken
        scene["duration_sec"] = fitted
        total_after += fitted

        flag = "  ← 무음 과다" if gap > MAX_GAP else ""
        print(f"  {scene['id']}: 발화 {spoken:4.1f}초 / 무음 {gap:4.1f}초 → {fitted}초{flag}")

    script_path.write_text(
        json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    print(f"\n[완료] 총 {total_before:.0f}초 → {total_after:.0f}초")
    print("  → generate_tts.py를 다시 실행해 보정된 길이로 오디오를 재생성하세요.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
