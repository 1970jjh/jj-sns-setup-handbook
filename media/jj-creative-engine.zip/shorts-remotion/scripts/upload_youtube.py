"""Phase 5: YouTube 공개 업로드

OAuth2 인증 -> 영상 업로드 -> 메타데이터 설정 -> 썸네일 업로드
"""
import os
import sys
import json
import glob
import pickle
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube",
]

PROJECT_ROOT = Path(__file__).parent.parent
_OUTPUT_BASE = Path(os.environ.get("OUTPUT_DIR", str(PROJECT_ROOT / "out")))
TOKEN_PATH = PROJECT_ROOT / "secrets" / "youtube_token.pickle"
CLIENT_SECRET_PATTERN = "C:/Users/YOUR_NAME/client_secret_*.json"


def get_credentials():
    creds = None

    if TOKEN_PATH.exists():
        with open(TOKEN_PATH, "rb") as f:
            creds = pickle.load(f)

    if creds and creds.valid:
        return creds

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        client_secrets = glob.glob(CLIENT_SECRET_PATTERN)
        if not client_secrets:
            print("ERROR: OAuth client_secret JSON 파일을 찾을 수 없습니다.")
            print(f"  패턴: {CLIENT_SECRET_PATTERN}")
            sys.exit(1)

        flow = InstalledAppFlow.from_client_secrets_file(client_secrets[0], SCOPES)
        creds = flow.run_local_server(port=8090, open_browser=True)

    TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(TOKEN_PATH, "wb") as f:
        pickle.dump(creds, f)

    return creds


def upload_video(
    video_path: str,
    title: str,
    description: str,
    tags: list[str],
    thumbnail_path: str | None = None,
    category_id: str = "27",
    privacy: str = "public",
) -> dict:
    creds = get_credentials()
    youtube = build("youtube", "v3", credentials=creds)

    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tags,
            "categoryId": category_id,
            "defaultLanguage": "ko",
            "defaultAudioLanguage": "ko",
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        },
    }

    print(f"업로드 중: {video_path}")
    print(f"  제목: {title}")
    print(f"  공개 상태: {privacy}")

    media = MediaFileUpload(video_path, mimetype="video/mp4", resumable=True)

    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media,
    )

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"  진행: {int(status.progress() * 100)}%")

    video_id = response["id"]
    video_url = f"https://youtu.be/{video_id}"
    print(f"\n업로드 완료: {video_url}")

    if thumbnail_path and os.path.exists(thumbnail_path):
        print(f"썸네일 업로드: {thumbnail_path}")
        youtube.thumbnails().set(
            videoId=video_id,
            media_body=MediaFileUpload(thumbnail_path, mimetype="image/png"),
        ).execute()
        print("  썸네일 설정 완료")

    result = {
        "video_id": video_id,
        "url": video_url,
        "title": title,
        "privacy": privacy,
        "status": "uploaded",
    }

    report_path = _OUTPUT_BASE / "upload_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"보고서 저장: {report_path}")

    return result


def main():
    video_path = os.environ.get("VIDEO_PATH", str(PROJECT_ROOT / "out" / "video.mp4"))
    thumbnail_path = str(PROJECT_ROOT / "public" / "scene_01_hook.png")

    if not os.path.exists(video_path):
        print(f"ERROR: 영상 파일 없음 - {video_path}")
        sys.exit(1)

    script_path = PROJECT_ROOT / "public" / "script.json"
    script_data = json.loads(script_path.read_text(encoding="utf-8"))

    title = script_data.get("title", "교육 영상") + " | JJ Creative 교육연구소"
    scenes = script_data.get("scenes", [])

    tags = list({kw for s in scenes for kw in s.get("keywords", [])})[:10]
    tags += ["기업교육", "워크숍", "JJ Creative", "교육연구소", "리더십"]

    toc_lines = []
    elapsed = 0
    for s in scenes:
        mins, secs = divmod(int(elapsed), 60)
        label = s.get("keywords", [""])[0] or s.get("id", "")
        toc_lines.append(f"{mins}:{secs:02d} {label}")
        elapsed += s.get("duration_sec", 10)

    toc = "\n".join(toc_lines)
    tag_str = " ".join(f"#{t.replace(' ', '')}" for t in tags[:8])

    desc_title = script_data.get("description", script_data.get("title", ""))

    description = f"""{desc_title}

목차
{toc}

{tag_str}

JJ Creative 교육연구소
문의: YOUR_EMAIL@example.com
"""

    result = upload_video(
        video_path=video_path,
        title=title,
        description=description,
        tags=tags,
        thumbnail_path=thumbnail_path,
        privacy=os.environ.get("YT_PRIVACY", "public"),
    )

    print(f"\n=== 최종 결과 ===")
    print(f"YouTube URL: {result['url']}")
    print(f"영상 ID: {result['video_id']}")


if __name__ == "__main__":
    main()
