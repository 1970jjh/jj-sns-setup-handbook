"""TTS 나레이션 생성 + 자막 타이밍 생성 (Edge / ElevenLabs / Gemini 트리플 엔진)"""
import asyncio
import base64
import json
import os
import subprocess
import sys
import urllib.request
import urllib.error
from pathlib import Path

import edge_tts

try:
    import imageio_ffmpeg
    FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
except ImportError:
    FFMPEG = "ffmpeg"

PROJECT_ROOT = Path(__file__).parent.parent

# .env 로드
_env_path = PROJECT_ROOT / ".env"
if _env_path.exists():
    for _line in _env_path.read_text(encoding="utf-8").splitlines():
        if "=" in _line and not _line.strip().startswith("#"):
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip())

OUTPUT_DIR = Path(os.environ.get("OUTPUT_DIR", str(PROJECT_ROOT / "public")))
SCRIPT_PATH = OUTPUT_DIR / "script.json"

# === 엔진 선택 === (edge | eleven | gemini)
TTS_ENGINE = os.environ.get("TTS_ENGINE", "edge").lower()

# === Edge TTS (무료 무제한) ===
VOICE = "ko-KR-SunHiNeural"
VOICE_FEMALE = "ko-KR-SunHiNeural"
VOICE_MALE = "ko-KR-InJoonNeural"

# === ElevenLabs (무료 10,000자/월) ===
EL_API_KEY = os.environ.get("ELEVENLABS_API_KEY", "")
EL_MODEL = os.environ.get("ELEVENLABS_MODEL", "eleven_multilingual_v2")
EL_VOICE_MALE = os.environ.get("ELEVENLABS_VOICE_MALE", "nPczCjzI2devNBz1zQrb")   # Brian
EL_VOICE_FEMALE = os.environ.get("ELEVENLABS_VOICE_FEMALE", "EXAVITQu4vr4xnSDxMaL")  # Sarah

# === Gemini 3.1 Flash TTS (default, 감정 프리픽스 + 씬별 스타일) ===
# 재사용 모듈 scripts/gemini_tts.py 를 우선 사용. 레거시 urllib 경로는 폴백.
def _load_gemini_key_from_env_file() -> str:
    from pathlib import Path as _P
    env_path = _P(__file__).parent.parent / ".env"
    if env_path.exists():
        for _line in env_path.read_text().splitlines():
            if _line.startswith("GEMINI_API_KEY="):
                _k = _line.split("=", 1)[1].strip()
                if _k:
                    os.environ["GOOGLE_API_KEY"] = _k
                    os.environ["GEMINI_API_KEY"] = _k
                    return _k
    return os.environ.get("GEMINI_API_KEY", "")
GM_API_KEY = _load_gemini_key_from_env_file()
# 기본 모델은 Gemini 3.1 Flash TTS Preview (2026-04 현재 최신).
# 구형 fallback 을 원하면 GEMINI_TTS_MODEL=gemini-2.5-flash-preview-tts 로 .env 지정.
GM_MODEL = os.environ.get("GEMINI_TTS_MODEL", "gemini-3.1-flash-tts-preview")
# Gemini prebuilt voice 중 한국어 내레이션 기본값
GM_VOICE_MALE = os.environ.get("GEMINI_VOICE_MALE", "Charon")  # 깊고 따뜻한 남성
GM_VOICE_FEMALE = os.environ.get("GEMINI_VOICE_FEMALE", "Leda")  # 밝고 따뜻한 여성
GM_STYLE_PREFIX = os.environ.get(
    "GEMINI_STYLE_PREFIX",
    "Say warmly with a bright, friendly Korean narrator tone",
)

# Prefer the reusable module when available
try:
    from gemini_tts import synth as _gm_synth, STYLES as _GM_STYLES  # type: ignore
    _HAS_GM_MODULE = True
except Exception:
    _HAS_GM_MODULE = False
    _GM_STYLES = {}


def elevenlabs_synthesize(text: str, voice_id: str, output_path: str, speed: float = 1.2) -> None:
    """ElevenLabs API로 MP3 합성 (speed 0.7~1.2 범위, 1.2 = 약 1.25배속 효과)"""
    # ElevenLabs speed 허용 범위: 0.7 ~ 1.2
    speed = max(0.7, min(1.2, speed))
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    payload = json.dumps({
        "text": text,
        "model_id": EL_MODEL,
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.75,
            "style": 0.0,
            "use_speaker_boost": True,
            "speed": speed,
        },
    }).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "xi-api-key": EL_API_KEY,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            audio = resp.read()
        with open(output_path, "wb") as f:
            f.write(audio)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"ElevenLabs API error {e.code}: {body}")


def gemini_synthesize(text: str, voice_name: str, output_path: str, speed: float = 1.25) -> None:
    """Gemini TTS로 PCM 합성 후 ffmpeg로 MP3 + 속도 조정."""
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/{GM_MODEL}"
        f":generateContent?key={GM_API_KEY}"
    )
    # 스타일 프리픽스로 톤 힌트 부여
    prompt_text = f"{GM_STYLE_PREFIX}{text}" if GM_STYLE_PREFIX else text
    payload = json.dumps({
        "contents": [{"parts": [{"text": prompt_text}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {
                "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice_name}}
            },
        },
    }).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Gemini TTS error {e.code}: {body}")

    parts = data["candidates"][0]["content"]["parts"]
    audio_b64 = parts[0]["inlineData"]["data"]
    pcm_bytes = base64.b64decode(audio_b64)

    # PCM(s16le 24kHz mono) → MP3 변환 + 배속 적용
    pcm_path = output_path.replace(".mp3", ".pcm")
    with open(pcm_path, "wb") as f:
        f.write(pcm_bytes)
    atempo = f"atempo={max(0.5, min(2.0, speed))}"
    subprocess.run(
        [FFMPEG, "-y", "-f", "s16le", "-ar", "24000", "-ac", "1", "-i", pcm_path,
         "-af", atempo, "-codec:a", "libmp3lame", "-b:a", "192k", output_path],
        capture_output=True,
    )
    try:
        os.remove(pcm_path)
    except OSError:
        pass


def get_audio_duration(filepath: str) -> float:
    """ffmpeg로 오디오 길이 측정"""
    result = subprocess.run(
        [FFMPEG, "-i", filepath, "-f", "null", "-"],
        capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    stderr = result.stderr
    for line in stderr.split("\n"):
        if "Duration:" in line:
            parts = line.split("Duration:")[1].split(",")[0].strip()
            h, m, s = parts.split(":")
            return int(h) * 3600 + int(m) * 60 + float(s)
    return 0.0


def add_silence_padding(input_path: str, output_path: str, target_sec: float, actual_sec: float):
    """타겟 시간에 맞게 무음 패딩 추가"""
    if actual_sec >= target_sec:
        # 패딩 불필요, 그냥 복사
        subprocess.run(
            [FFMPEG, "-y", "-i", input_path, "-c", "copy", output_path],
            capture_output=True
        )
    else:
        # 무음 추가
        pad_sec = target_sec - actual_sec
        subprocess.run(
            [FFMPEG, "-y", "-i", input_path,
             "-af", f"apad=pad_dur={pad_sec}",
             "-codec:a", "libmp3lame", "-b:a", "192k",
             output_path],
            capture_output=True
        )


def concat_audio_files(file_list: list[str], output_path: str):
    """여러 오디오 파일을 연결"""
    list_file = str(OUTPUT_DIR / "concat_list.txt")
    with open(list_file, "w", encoding="utf-8") as f:
        for fp in file_list:
            f.write(f"file '{fp}'\n")

    subprocess.run(
        [FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", list_file,
         "-codec:a", "libmp3lame", "-b:a", "192k", output_path],
        capture_output=True
    )
    os.remove(list_file)


def split_narration(text: str) -> list[str]:
    """나레이션을 자연스러운 문장 단위로 분할"""
    segments = []
    current = ""
    for char in text:
        current += char
        if char in ".!?" and len(current.strip()) > 3:
            segments.append(current.strip())
            current = ""
        elif char == "," and len(current.strip()) > 20:
            segments.append(current.strip())
            current = ""
    if current.strip():
        segments.append(current.strip())
    return [s for s in segments if s]


async def main():
    if not SCRIPT_PATH.exists():
        print(f"ERROR: {SCRIPT_PATH} not found")
        sys.exit(1)

    script = json.loads(SCRIPT_PATH.read_text(encoding="utf-8"))
    scenes = script["scenes"]

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if TTS_ENGINE == "eleven":
        print("=== ElevenLabs TTS 나레이션 생성 ===")
        print(f"  Model: {EL_MODEL}")
        print(f"  Male voice: {EL_VOICE_MALE}  Female voice: {EL_VOICE_FEMALE}")
    elif TTS_ENGINE == "gemini":
        print("=== Gemini TTS 나레이션 생성 ===")
        print(f"  Model: {GM_MODEL}")
        print(f"  Male: {GM_VOICE_MALE}  Female: {GM_VOICE_FEMALE}")
    else:
        print("=== Edge TTS 나레이션 생성 ===")
        print(f"  Male: {VOICE_MALE}  Female: {VOICE_FEMALE}")
    print(f"  Scenes: {len(scenes)}")

    padded_files = []
    all_subtitles = []
    cumulative_time = 0.0

    for i, scene in enumerate(scenes):
        scene_id = scene["id"]
        narration = scene["narration"]
        temp_path = str(OUTPUT_DIR / f"temp_{scene_id}.mp3")
        padded_path = str(OUTPUT_DIR / f"padded_{scene_id}.mp3")

        print(f"[{i+1}/{len(scenes)}] {scene_id}...")

        # 씬별 음성 선택 (voice 필드: "male" | "female", 기본 female)
        is_male = scene.get("voice") == "male"

        # TTS 생성 (최대 3회 재시도)
        for attempt in range(3):
            try:
                if TTS_ENGINE == "eleven":
                    if not EL_API_KEY:
                        raise RuntimeError("ELEVENLABS_API_KEY 미설정")
                    voice_id = scene.get("voice_id") or (EL_VOICE_MALE if is_male else EL_VOICE_FEMALE)
                    elevenlabs_synthesize(narration, voice_id, temp_path, speed=1.2)
                elif TTS_ENGINE == "gemini":
                    if not GM_API_KEY:
                        raise RuntimeError("GEMINI_API_KEY 미설정")
                    gm_voice = scene.get("voice_name") or (GM_VOICE_MALE if is_male else GM_VOICE_FEMALE)
                    # 씬별 감정 스타일: scene["style"] 이 있으면 사용.
                    # preset key("warm","excited"...) 또는 raw instruction 모두 허용.
                    gm_style = scene.get("style") or GM_STYLE_PREFIX
                    if _HAS_GM_MODULE:
                        wav_tmp = temp_path.replace(".mp3", ".wav")
                        _gm_synth(narration, voice=gm_voice, style=gm_style,
                                  out_path=wav_tmp, speed=1.2, stereo=True)
                        # WAV -> MP3 (downstream pipeline assumes .mp3)
                        subprocess.run(
                            [FFMPEG, "-y", "-i", wav_tmp,
                             "-codec:a", "libmp3lame", "-b:a", "192k", temp_path],
                            capture_output=True,
                        )
                        try:
                            os.remove(wav_tmp)
                        except OSError:
                            pass
                    else:
                        gemini_synthesize(narration, gm_voice, temp_path, speed=1.25)
                else:
                    scene_voice = VOICE_MALE if is_male else VOICE_FEMALE
                    communicate = edge_tts.Communicate(narration, scene_voice, rate="+25%", pitch="+0Hz")
                    await communicate.save(temp_path)
                break
            except Exception as e:
                print(f"  재시도 {attempt+1}/3: {e}")
                await asyncio.sleep(2)
                if attempt == 2:
                    raise

        # 오디오 길이 측정
        audio_duration = get_audio_duration(temp_path)
        target_duration = scene["duration_sec"]

        # 오디오가 타겟보다 길면 타겟 조정
        if audio_duration > target_duration + 0.5:
            target_duration = int(audio_duration) + 1
            scene["duration_sec"] = target_duration

        # 패딩 추가
        add_silence_padding(temp_path, padded_path, target_duration, audio_duration)
        padded_files.append(padded_path)

        # 자막 생성
        sentences = split_narration(narration)
        effective_duration = min(audio_duration, target_duration)
        time_per_sentence = effective_duration / max(len(sentences), 1)

        for j, sentence in enumerate(sentences):
            start = cumulative_time + j * time_per_sentence
            end = cumulative_time + (j + 1) * time_per_sentence
            all_subtitles.append({
                "text": sentence,
                "start": round(start, 2),
                "end": round(end, 2)
            })

        cumulative_time += target_duration
        os.remove(temp_path)

        print(f"  Audio: {audio_duration:.1f}s -> Padded: {target_duration}s")

    # 전체 오디오 병합
    print("\n전체 오디오 병합 중...")
    output_path = str(OUTPUT_DIR / "narration_full.mp3")
    concat_audio_files(padded_files, output_path)

    final_duration = get_audio_duration(output_path)
    print(f"Final audio: {final_duration:.1f}s -> {output_path}")

    # 임시 파일 정리
    for f in padded_files:
        if os.path.exists(f):
            os.remove(f)

    # script.json 업데이트 (duration 보정)
    with open(SCRIPT_PATH, "w", encoding="utf-8") as f:
        json.dump(script, f, ensure_ascii=False, indent=2)

    # 자막 JSON 저장
    subtitles_path = str(OUTPUT_DIR / "subtitles.json")
    with open(subtitles_path, "w", encoding="utf-8") as f:
        json.dump(all_subtitles, f, ensure_ascii=False, indent=2)
    print(f"Subtitles: {len(all_subtitles)} entries -> {subtitles_path}")

    print(f"\n=== 완료 ===")
    print(f"총 영상 길이: {cumulative_time:.0f}초 ({cumulative_time/60:.1f}분)")


if __name__ == "__main__":
    asyncio.run(main())
