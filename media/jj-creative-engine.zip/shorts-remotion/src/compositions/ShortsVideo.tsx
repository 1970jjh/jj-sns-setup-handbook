import React, { useEffect, useState } from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  Sequence,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
  staticFile,
  delayRender,
  continueRender,
} from "remotion";
import { Subtitles } from "../components/Subtitles";

/**
 * 유튜브 쇼츠(1080x1920) 컴포지션.
 *
 * EducationVideo(가로 16:9, 3~5분)와 목적이 다르다:
 *  - 세로 화면이라 이미지를 꽉 채우지 않고 상단에 배치, 하단은 자막 영역으로 비운다
 *  - 60초 안에 끝나야 하므로 씬당 8~12초, 5~6씬을 전제로 한다
 *  - 첫 1초가 이탈을 좌우하므로 인트로 페이드를 짧게 가져간다
 *
 * public/shorts/<slug>/ 에 script.json / subtitles.json / narration_full.mp3 /
 * scene_01.png ... 를 두고 렌더한다.
 */

// 세로에서는 줌만 쓴다. 가로 팬을 크게 주면 좌우가 잘려 보인다.
const ZOOM_PATTERNS = [
  { start: 1.0, end: 1.12 },
  { start: 1.1, end: 1.0 },
  { start: 1.0, end: 1.08 },
  { start: 1.08, end: 1.0 },
];

/**
 * 세로 화면 배치 기준 (1080x1920)
 *
 * 유튜브 쇼츠는 화면 위아래를 UI가 덮는다.
 *  - 하단 약 320px: 제목·채널명·설명
 *  - 우측 약 140px: 좋아요/댓글/공유 버튼
 * 그래서 내용을 화면 정중앙 띠 안에 몰아넣어야 잘리지 않는다.
 */
const SAFE_TOP = 250;        // 상단 여백
const IMAGE_HEIGHT = 1080;   // 1:1 카드가 그대로 들어가는 높이
const SUBTITLE_LIFT = 380;   // 자막을 하단 UI(약 320px) 위로 끌어올린다
// 카드 이미지 자체에 큰 한글 제목이 들어 있으므로 별도 캡션은 넣지 않는다.
// 이미지=헤드라인, 자막=내레이션으로 역할을 나눈다 (겹침·중복 방지).

interface SceneProps {
  readonly imageFile: string;
  readonly sceneIndex: number;
  readonly durationFrames: number;
}

const Scene: React.FC<SceneProps> = ({
  imageFile,
  sceneIndex,
  durationFrames,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const zoom = ZOOM_PATTERNS[sceneIndex % ZOOM_PATTERNS.length];

  const progress = interpolate(frame, [0, durationFrames], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const scale = interpolate(progress, [0, 1], [zoom.start, zoom.end]);

  // 씬 전환은 짧게 (쇼츠는 템포가 생명)
  const fadeFrames = Math.min(6, Math.round(fps * 0.2));
  const opacity = interpolate(
    frame,
    [0, fadeFrames, durationFrames - fadeFrames, durationFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );

  return (
    <AbsoluteFill style={{ opacity, backgroundColor: "#ffffff" }}>
      <div
        style={{
          position: "absolute",
          top: SAFE_TOP,
          left: 0,
          width: "100%",
          height: IMAGE_HEIGHT,
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#ffffff",
        }}
      >
        <Img
          src={staticFile(imageFile)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "contain",
            transform: `scale(${scale})`,
          }}
        />
      </div>

    </AbsoluteFill>
  );
};

export const ShortsVideo: React.FC = () => {
  const [scriptData, setScriptData] = useState<any>(null);
  const [subtitleData, setSubtitleData] = useState<any[]>([]);
  const [handle] = useState(() => delayRender("Loading shorts script..."));

  useEffect(() => {
    Promise.all([
      fetch(staticFile("script.json")).then((r) => r.json()),
      fetch(staticFile("subtitles.json"))
        .then((r) => r.json())
        .catch(() => []),
    ]).then(([script, subs]) => {
      setScriptData(script);
      setSubtitleData(subs);
      continueRender(handle);
    });
  }, [handle]);

  if (!scriptData) return null;

  const scenes = scriptData.scenes || [];
  const fps = 30;
  let currentFrame = 0;

  return (
    <AbsoluteFill style={{ backgroundColor: "#ffffff" }}>
      {scenes.map((scene: any, index: number) => {
        const from = currentFrame;
        const durationFrames = (scene.duration_sec || 10) * fps;
        currentFrame += durationFrames;

        return (
          <Sequence key={scene.id} from={from} durationInFrames={durationFrames}>
            <Scene
              imageFile={`${scene.id}.png`}
              sceneIndex={index}
              durationFrames={durationFrames}
            />
          </Sequence>
        );
      })}

      <Audio src={staticFile("narration_full.mp3")} volume={1} />

      {/* AbsoluteFill은 자체 bottom:0을 갖고 있어 덮어쓰기가 안 먹는다.
          일반 div로 감싸 자막을 하단 UI 위로 끌어올린다. */}
      {subtitleData.length > 0 && (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: SUBTITLE_LIFT,
          }}
        >
          <Subtitles data={subtitleData} />
        </div>
      )}
    </AbsoluteFill>
  );
};
