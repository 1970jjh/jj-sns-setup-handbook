import React from "react";
import { Composition } from "remotion";
import { ShortsVideo } from "./compositions/ShortsVideo";

// 유튜브 쇼츠 세로 규격 1080x1920. 60초 이내여야 쇼츠로 분류된다.
export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="ShortsVideo"
      component={ShortsVideo}
      durationInFrames={30 * 60}
      fps={30}
      width={1080}
      height={1920}
      defaultProps={{}}
    />
  </>
);
