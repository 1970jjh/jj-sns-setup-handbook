import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
  Easing,
} from "remotion";

interface SubtitleEntry {
  text: string;
  start: number;
  end: number;
}

interface SubtitlesProps {
  readonly data: readonly SubtitleEntry[];
}

export const Subtitles: React.FC<SubtitlesProps> = ({ data }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentTime = frame / fps;

  const active = data.find(
    (s) => currentTime >= s.start && currentTime <= s.end
  );

  if (!active) return null;

  const duration = active.end - active.start;
  const elapsed = currentTime - active.start;

  // 페이드인/아웃
  const opacity =
    duration > 0.4
      ? interpolate(
          elapsed,
          [0, 0.15, duration - 0.15, duration],
          [0, 1, 1, 0],
          { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
        )
      : 1;

  // 등장 시 살짝 위로 슬라이드
  const slideUp = interpolate(elapsed, [0, 0.2], [8, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });

  // 스케일 바운스 (등장 시)
  const entryFrame = Math.round(active.start * fps);
  const localFrame = frame - entryFrame;
  const scale = spring({
    frame: Math.max(0, localFrame),
    fps,
    config: { damping: 80, stiffness: 300, mass: 0.3 },
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-end",
        alignItems: "center",
        paddingBottom: 50,
      }}
    >
      <div
        style={{
          opacity,
          transform: `translateY(${slideUp}px) scale(${Math.min(scale, 1.02)})`,
          backgroundColor: "rgba(0, 0, 0, 0.75)",
          padding: "14px 40px",
          borderRadius: 10,
          maxWidth: 1500,
          textAlign: "center",
          backdropFilter: "blur(6px)",
          borderBottom: "2px solid rgba(74, 144, 217, 0.6)",
        }}
      >
        <span
          style={{
            color: "#FFFFFF",
            fontSize: 38,
            fontWeight: 600,
            fontFamily: "'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif",
            lineHeight: 1.5,
            letterSpacing: 0.5,
            textShadow: "0 1px 4px rgba(0,0,0,0.5)",
          }}
        >
          {active.text}
        </span>
      </div>
    </AbsoluteFill>
  );
};
